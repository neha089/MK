<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function create()
    {
        return view('admin.add-product');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'brand' => 'nullable|string|max:255',
            'model' => 'nullable|string|max:255',
            'capacity' => 'nullable|string|max:255',
            'rating' => 'nullable|string|max:255',
            'price' => 'required|numeric',
            'mrp' => 'nullable|numeric',
            'desc' => 'nullable|string',
            'image_file' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
        ]);

        $imagePath = null;
        if ($request->hasFile('image_file')) {
            $imagePath = $request->file('image_file')->store('products', 'public');
            // the URL will be /storage/products/filename.jpg
            $validated['image'] = '/storage/' . $imagePath;
        }

        Product::create($validated);

        return redirect()->route('admin.product.create')->with('success', 'Product added successfully!');
    }
}
