<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name', 'brand', 'model', 'capacity', 'rating', 'reviews',
        'price', 'mrp', 'desc', 'image'
    ];
}
