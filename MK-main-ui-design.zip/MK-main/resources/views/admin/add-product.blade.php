<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Admin | Add Product</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-surface text-on-surface font-body p-10">

<div class="max-w-3xl mx-auto bg-white p-8 rounded-3xl shadow-xl border border-outline-variant/40">
    <div class="flex items-center gap-3 mb-8">
        <span class="material-symbols-outlined text-4xl text-primary">add_circle</span>
        <h1 class="text-3xl font-extrabold font-headline">Add New Product</h1>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 relative" role="alert">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif

    <form action="{{ route('admin.product.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        
        <div class="grid grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-bold mb-2">Product Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" required class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
            <div>
                <label class="block text-sm font-bold mb-2">Brand</label>
                <input type="text" name="brand" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
        </div>

        <div class="grid grid-cols-3 gap-6">
            <div>
                <label class="block text-sm font-bold mb-2">Model</label>
                <input type="text" name="model" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
            <div>
                <label class="block text-sm font-bold mb-2">Capacity</label>
                <input type="text" name="capacity" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
            <div>
                <label class="block text-sm font-bold mb-2">Rating</label>
                <input type="text" name="rating" step="0.1" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-bold mb-2">Selling Price (₹) <span class="text-red-500">*</span></label>
                <input type="number" name="price" required class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
            <div>
                <label class="block text-sm font-bold mb-2">MRP (₹)</label>
                <input type="number" name="mrp" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition">
            </div>
        </div>

        <div>
            <label class="block text-sm font-bold mb-2">Description</label>
            <textarea name="desc" rows="4" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition"></textarea>
        </div>

        <div>
            <label class="block text-sm font-bold mb-2">Product Image (Upload File)</label>
            <input type="file" name="image_file" accept="image/*" class="w-full p-3 border border-outline-variant/60 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-surface-container-lowest">
        </div>

        <div class="pt-4 border-t border-outline-variant/30 flex items-center justify-end gap-4">
            <a href="{{ route('dashboard') }}" class="px-6 py-3 border border-outline-variant/60 rounded-xl font-bold hover:bg-surface-container-low transition">Back to Store</a>
            <button type="submit" class="bg-primary text-on-primary px-8 py-3 rounded-xl font-bold hover:bg-primary-container hover:text-on-primary-container transition shadow-md">
                Save Product
            </button>
        </div>
    </form>
</div>

</body>
</html>
