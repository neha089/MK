<!DOCTYPE html>
<html class="light" lang="en">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>HomeKart - Premium Smart Home Appliances</title>
    
    <!-- Material Symbols Outlined & Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=block" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&amp;family=Plus+Jakarta+Sans:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
    
    <!-- Three.js (For Particle background) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>

    <!-- Vite Assets -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-background text-on-surface font-body overflow-hidden min-h-screen flex items-center justify-center">

<!-- Immersive Background Layer -->
<div class="fixed inset-0 w-full h-full z-0 overflow-hidden">
    <img alt="High-end showroom with premium appliances" class="absolute inset-0 w-full h-full object-cover scale-105 filter blur-[1px]" src="{{ asset('images/appliance_showroom.png') }}"/>
    <div class="absolute inset-0 bg-black/35 backdrop-blur-[2px]"></div>
</div>

<!-- Three.js Layer -->
<div class="fixed inset-0 w-full h-full z-[1] pointer-events-none" id="threejs-container"></div>

<!-- Main Content Container -->
<main class="relative z-10 w-full max-w-[460px] px-margin-mobile animate-fade-in flex flex-col items-center">
    
    <!-- Branding Top -->
    <div class="text-center mb-6 animate-slide-up flex flex-col items-center" style="animation-delay: 0.1s;">
        <!-- Logo Emblem -->
        <div class="w-14 h-14 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20 shadow-lg mb-4">
            <span class="material-symbols-outlined text-white text-3xl" style="font-variation-settings: 'FILL' 1;">widgets</span>
        </div>
        <h1 class="font-headline text-4xl font-extrabold text-white drop-shadow-md tracking-tight">HomeKart</h1>
        <p class="font-sans text-sm text-white/80 mt-2 font-medium tracking-wide">Premium Smart Home Appliances</p>
    </div>
    
    <!-- Premium Glassmorphism Card -->
    <div class="glass-card rounded-2xl p-8 animate-slide-up w-full overflow-hidden" style="animation-delay: 0.2s;">
        
        <!-- Segmented Control Tab Slider -->
        <div class="bg-black/10 p-1 rounded-xl flex mb-8 relative border border-black/5">
            <!-- Active slide background pill -->
            <div class="absolute top-1 bottom-1 left-1 w-[calc(50%-4px)] bg-white/90 shadow-md rounded-lg transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]" id="activePill"></div>
            
            <button class="flex-1 py-2.5 font-headline text-sm text-primary font-bold z-10 transition-colors duration-300" id="loginTab" onclick="toggleForm('login')">
                Sign In
            </button>
            <button class="flex-1 py-2.5 font-headline text-sm text-white z-10 transition-colors duration-300" id="signupTab" onclick="toggleForm('signup')">
                Register
            </button>
        </div>
        
        <!-- Forms Container -->
        <div class="form-transition-container relative">
            
            <!-- LOGIN FORM -->
            <form class="form-section active-form space-y-5" id="loginForm">
                @csrf
                
                <!-- Email Input -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="loginEmail">Email Address</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">mail</span>
                        <input class="w-full glow-input py-3 pl-11 pr-4 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="loginEmail" name="email" placeholder="name@domain.com" required="" type="email"/>
                    </div>
                </div>
                
                <!-- Password Input -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="loginPass">Password</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">lock</span>
                        <input class="w-full glow-input py-3 pl-11 pr-12 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="loginPass" name="password" placeholder="••••••••" required="" type="password"/>
                        <button class="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/70 hover:text-white transition-colors" type="button" onclick="togglePasswordVisibility('loginPass', this)">
                            <span class="material-symbols-outlined text-[20px]" id="loginPassToggleIcon">visibility</span>
                        </button>
                    </div>
                </div>
                
                <!-- Remember & Forgot password -->
                <div class="flex items-center justify-between text-xs font-sans pt-1">
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input class="rounded border-white/30 bg-white/10 text-primary focus:ring-primary h-4 w-4" name="remember" type="checkbox"/>
                        <span class="text-white/80 group-hover:text-white transition-colors">Keep me signed in</span>
                    </label>
                    <a class="text-white font-semibold hover:underline transition-colors" href="#">Forgot Password?</a>
                </div>
                
                <!-- Submit Button -->
                <button class="relative overflow-hidden w-full metallic-btn text-white py-3.5 rounded-xl font-headline text-base font-bold shadow-lg transform active:translate-y-0.5 ripple-button" type="submit">
                    Sign In to HomeKart
                </button>
                
                <!-- OR Continue with divider -->
                <div class="relative flex items-center py-2">
                    <div class="flex-grow border-t border-white/20"></div>
                    <span class="flex-shrink mx-4 text-white/60 font-sans text-xs tracking-widest font-semibold uppercase">Or Connect With</span>
                    <div class="flex-grow border-t border-white/20"></div>
                </div>
                
                <!-- Social Connect Buttons -->
                <div class="flex gap-4">
                    <button class="flex-1 flex items-center justify-center gap-2.5 bg-white/15 border border-white/25 py-3 rounded-xl hover:bg-white/25 transition-all group active:scale-95" type="button">
                        <img alt="Google" class="w-4.5 h-4.5" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBpM0PEvldRyek9-gxjubjjcESTx1GX8wCATxOLzu-FEAERSZ1HxQb_l2J3tS8mew7IAOHswubMc6Nf9fZCPk-vpJDFSmBvIvvo0PkvRQ3qe6Qr3YZPtN_3ZPq_uOCokNHl7GzcRC0tDqErmKWwHb3FvSQzo8SiDnNs1juWwxg_KUPhGOaRLlEd8zMexK-ZGB2ceEd0i-s5UJpjsyghR-ciGaOnkecidN2JQXwX4nJunWfgwEdGu2Ve"/>
                        <span class="font-sans text-xs text-white font-bold tracking-wide">Google</span>
                    </button>
                    <button class="flex-1 flex items-center justify-center gap-2 bg-white/15 border border-white/25 py-3 rounded-xl hover:bg-white/25 transition-all group active:scale-95" type="button">
                        <span class="material-symbols-outlined text-[20px] text-white" style="font-variation-settings: 'FILL' 1;">apps</span>
                        <span class="font-sans text-xs text-white font-bold tracking-wide">Apple</span>
                    </button>
                </div>
            </form>
            
            <!-- SIGN UP FORM -->
            <form class="form-section hidden-form space-y-5" id="signupForm">
                @csrf
                
                <!-- Full Name -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="signupName">Full Name</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">person</span>
                        <input class="w-full glow-input py-3 pl-11 pr-4 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="signupName" name="name" placeholder="John Doe" required="" type="text"/>
                    </div>
                </div>
                
                <!-- Email Address -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="signupEmail">Email Address</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">mail</span>
                        <input class="w-full glow-input py-3 pl-11 pr-4 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="signupEmail" name="email" placeholder="name@domain.com" required="" type="email"/>
                    </div>
                </div>
                
                <!-- Create Password -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="signupPass">Create Password</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">lock</span>
                        <input class="w-full glow-input py-3 pl-11 pr-12 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="signupPass" name="password" placeholder="••••••••" required="" type="password"/>
                    </div>
                </div>
                
                <!-- Confirm Password -->
                <div class="space-y-1.5">
                    <label class="text-xs font-semibold text-white/90 tracking-wider uppercase pl-1" for="confirmPass">Confirm Password</label>
                    <div class="relative">
                        <span class="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-primary text-xl">lock</span>
                        <input class="w-full glow-input py-3 pl-11 pr-12 rounded-xl text-white placeholder-white/50 text-sm focus:outline-none" id="confirmPass" name="password_confirmation" placeholder="••••••••" required="" type="password"/>
                    </div>
                </div>
                
                <!-- Terms -->
                <div class="flex items-start gap-2.5 text-xs font-sans py-1">
                    <input class="mt-0.5 rounded border-white/30 bg-white/10 text-primary focus:ring-primary h-4 w-4" id="terms" required="" type="checkbox"/>
                    <label class="text-white/80" for="terms">
                        I agree to the <a class="text-white font-bold hover:underline" href="#">Terms of Service</a> and <a class="text-white font-bold hover:underline" href="#">Privacy Policy</a>.
                    </label>
                </div>
                
                <!-- Submit -->
                <button class="relative overflow-hidden w-full metallic-btn text-white py-3.5 rounded-xl font-headline text-base font-bold shadow-lg transform active:translate-y-0.5 ripple-button" type="submit">
                    Create Account
                </button>
            </form>
        </div>
    </div>
    
    <!-- Support Links -->
    <div class="flex justify-center gap-gutter mt-8 animate-slide-up" style="animation-delay: 0.3s;">
        <a class="text-white/80 font-sans text-xs hover:text-white transition-colors drop-shadow-sm font-semibold" href="#">Privacy</a>
        <a class="text-white/80 font-sans text-xs hover:text-white transition-colors drop-shadow-sm font-semibold" href="#">Help Center</a>
        <a class="text-white/80 font-sans text-xs hover:text-white transition-colors drop-shadow-sm font-semibold" href="#">Contact</a>
    </div>
</main>

<script>
    // Three.js Scene Initialization
    let scene, camera, renderer, particles;
    function initThree() {
        try {
            scene = new THREE.Scene();
            camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
            renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
            renderer.setSize(window.innerWidth, window.innerHeight);
            document.getElementById('threejs-container').appendChild(renderer.domElement);

            const geometry = new THREE.BufferGeometry();
            const vertices = [];
            for (let i = 0; i < 1200; i++) {
                vertices.push(
                    THREE.MathUtils.randFloatSpread(2000),
                    THREE.MathUtils.randFloatSpread(2000),
                    THREE.MathUtils.randFloatSpread(2000)
                );
            }
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
            const material = new THREE.PointsMaterial({ color: 0xffffff, size: 1.8, transparent: true, opacity: 0.45 });
            particles = new THREE.Points(geometry, material);
            scene.add(particles);
            camera.position.z = 1000;

            function animate() {
                requestAnimationFrame(animate);
                particles.rotation.x += 0.0004;
                particles.rotation.y += 0.0004;
                renderer.render(scene, camera);
            }
            animate();
        } catch (e) {
            console.error("Three.js initialization failed:", e);
        }
    }

    window.addEventListener('resize', () => {
        if (camera && renderer) {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }
    });

    // Initialize Three.js on load
    window.addEventListener('DOMContentLoaded', initThree);

    // Form Switching Logic with sliding pill indicator
    function toggleForm(type) {
        const loginForm = document.getElementById('loginForm');
        const signupForm = document.getElementById('signupForm');
        const loginTab = document.getElementById('loginTab');
        const signupTab = document.getElementById('signupTab');
        const activePill = document.getElementById('activePill');

        if (type === 'login') {
            loginForm.classList.remove('hidden-form');
            loginForm.classList.add('active-form');
            signupForm.classList.remove('active-form');
            signupForm.classList.add('hidden-form');

            loginTab.classList.add('text-primary');
            loginTab.classList.remove('text-white');
            signupTab.classList.add('text-white');
            signupTab.classList.remove('text-primary');

            // Slide pill to login position
            activePill.style.transform = 'translateX(0)';
        } else {
            signupForm.classList.remove('hidden-form');
            signupForm.classList.add('active-form');
            loginForm.classList.remove('active-form');
            loginForm.classList.add('hidden-form');

            signupTab.classList.add('text-primary');
            signupTab.classList.remove('text-white');
            loginTab.classList.add('text-white');
            loginTab.classList.remove('text-primary');

            // Slide pill to signup position
            activePill.style.transform = 'translateX(100%) translateX(4px)';
        }
    }

    // Toggle Password Visibility
    function togglePasswordVisibility(inputId, btn) {
        const input = document.getElementById(inputId);
        const icon = btn.querySelector('span');
        if (input.type === 'password') {
            input.type = 'text';
            icon.textContent = 'visibility_off';
        } else {
            input.type = 'password';
            icon.textContent = 'visibility';
        }
    }

    // Ripple Effect
    document.querySelectorAll('.ripple-button').forEach(button => {
        button.addEventListener('click', function(e) {
            let x = e.clientX - e.target.getBoundingClientRect().left;
            let y = e.clientY - e.target.getBoundingClientRect().top;
            
            let ripples = document.createElement('span');
            ripples.style.left = x + 'px';
            ripples.style.top = y + 'px';
            ripples.classList.add('ripple');
            this.appendChild(ripples);

            setTimeout(() => {
                ripples.remove();
            }, 600);
        });
    });

    // Magnetic Effect on Buttons
    const magneticButtons = document.querySelectorAll('.ripple-button');
    magneticButtons.forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const position = btn.getBoundingClientRect();
            const x = e.pageX - position.left - position.width / 2;
            const y = e.pageY - position.top - position.height / 2;
            
            btn.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
        });
        btn.addEventListener('mouseleave', (e) => {
            btn.style.transform = `translate(0px, 0px)`;
        });
    });

    // Form Submission Interactivity
    document.getElementById('loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const btn = e.target.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.innerHTML = '<span class="material-symbols-outlined animate-spin align-middle mr-2">sync</span> Signing in...';
        btn.style.opacity = '0.7';
        setTimeout(() => {
            window.location.href = "{{ route('dashboard') }}";
        }, 800);
    });

    document.getElementById('signupForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const btn = e.target.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.innerHTML = '<span class="material-symbols-outlined animate-spin align-middle mr-2">sync</span> Creating account...';
        btn.style.opacity = '0.7';
        setTimeout(() => {
            window.location.href = "{{ route('dashboard') }}";
        }, 1000);
    });
</script>
</body>
</html>
