<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>HomeKart | Premium Categories</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>

    <!-- Vite Assets (Tailwind CSS v4) -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            display: inline-block;
            vertical-align: middle;
        }
        .hero-banner-gradient {
            background: linear-gradient(135deg, #002253 0%, #0047ab 100%);
        }
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }
        .stagger-fade-in {
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInAnimation 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes fadeInAnimation {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .category-glow-card:hover {
            box-shadow: 
                0 20px 40px rgba(0, 71, 171, 0.08),
                0 0 0 1px rgba(0, 71, 171, 0.2);
            transform: translateY(-4px);
        }
    </style>
</head>
<body class="bg-surface text-on-surface font-body overflow-x-hidden antialiased">

<!-- Premium Navigation Bar -->
<header class="fixed top-0 w-full z-50 glass-nav border-b border-outline-variant/40 transition-all duration-300" id="main-header">
    <div class="flex items-center justify-between px-margin-desktop max-w-container-max mx-auto h-20">
        <div class="flex items-center gap-12">
            <a class="flex items-center gap-3 group" href="{{ route('dashboard') }}">
                <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md group-hover:scale-105 transition-transform">
                    <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                </div>
                <span class="font-headline text-2xl font-extrabold text-primary tracking-tight">HomeKart</span>
            </a>
        </div>
        
        <!-- Action Items -->
        <div class="flex items-center gap-8">
            <div class="hidden md:flex items-center gap-2.5 text-primary font-bold bg-primary-fixed/35 px-4 py-2 rounded-xl border border-primary/5">
                <span class="material-symbols-outlined text-lg text-primary">call</span>
                <span class="text-xs font-headline">+91 98765 43210</span>
                <img alt="whatsapp" class="w-5 h-5 ml-1 animate-pulse" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAn9kHDYUKFEgzRQBJpMmsfH72sxUJ-IXcPuukm6CeqTWJONQBiDl0Vag5qro_1pShClp94cSt1x_eUKyyYCQsn1s-vjXzKuh9aspswM6YtcgWaZIPrEPdIZT9bGmwVsB8ftQZ3W65Jo1b1Uzv1jiSyRNJLAuCL9bvOBEvf3flQM4NNem0YNSynIMgYJhWfKsGUbbT4CP8_npk7o7ObdsuXgtRyRACusVJ6Tu3V_X4Cd_Nc-oyuIt2C"/>
            </div>
            
            <div class="flex items-center gap-5">
                <a href="{{ route('dashboard') }}" class="flex items-center gap-2 text-sm font-bold text-primary hover:bg-primary-fixed/20 px-4 py-2.5 rounded-xl transition-all border border-primary/20 shadow-sm bg-white">
                    <span class="material-symbols-outlined text-lg">arrow_back</span>
                    Back to Store
                </a>
            </div>
        </div>
    </div>
    
    <!-- Sub Header Navigation -->
    <nav class="hidden lg:flex items-center justify-center gap-10 h-11 border-t border-outline-variant/40 text-xs uppercase tracking-widest font-bold text-on-surface-variant">
        <a class="hover:text-primary transition-colors relative py-2 group text-primary" href="{{ route('categories') }}">
            Categories
            <span class="absolute bottom-0 left-0 w-full h-0.5 bg-primary"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#products">
            Top Sellers
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#sale">
            Offers & Sales
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#brands">
            Partner Brands
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
    </nav>
</header>

<main class="pt-32">
    <!-- Premium Gradient Title & Filter Section -->
    <section class="max-w-container-max mx-auto px-margin-desktop my-10 reveal active">
        <div class="hero-banner-gradient rounded-[32px] p-8 lg:p-14 text-white relative overflow-hidden shadow-2xl border border-white/10 flex flex-col items-center text-center">
            <div class="absolute inset-0 opacity-10">
                <div class="w-full h-full" style="background-image: radial-gradient(circle at 2px 2px, white 2px, transparent 0); background-size: 24px 24px;"></div>
            </div>
            
            <div class="relative z-10 max-w-2xl space-y-4">
                <span class="bg-secondary-container text-on-secondary-container text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">Catalog Directory</span>
                <h1 class="font-headline text-4xl lg:text-5xl font-extrabold leading-tight">Our Premium Categories</h1>
                <p class="text-white/80 text-sm leading-relaxed max-w-lg mx-auto">
                    Explore our curate range of appliances engineered to bring modern luxury and energy efficiency to your home.
                </p>
                
                <!-- Advanced Search Input Inside Banner -->
                <div class="pt-6 relative max-w-md mx-auto">
                    <input id="category-search" class="w-full pl-6 pr-14 py-4 bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl focus:outline-none focus:bg-white focus:text-on-surface focus:border-white focus:ring-4 focus:ring-white/10 transition-all text-sm font-semibold placeholder-white/60 text-white" placeholder="Search categories..." type="text"/>
                    <button class="absolute right-2.5 top-[34px] bg-secondary-container text-on-secondary-container p-2.5 rounded-xl hover:opacity-95 transition-colors shadow-sm">
                        <span class="material-symbols-outlined text-[20px]">search</span>
                    </button>
                </div>

                <!-- Tag Filters -->
                <div class="flex flex-wrap justify-center gap-3 pt-6 text-xs font-bold" id="tag-filters">
                    <button class="px-4 py-2 rounded-xl bg-white text-primary shadow-sm transition-all" onclick="filterByTag('all', this)">All Categories</button>
                    <button class="px-4 py-2 rounded-xl bg-white/10 border border-white/20 hover:bg-white/25 transition-all" onclick="filterByTag('cooling', this)">Cooling</button>
                    <button class="px-4 py-2 rounded-xl bg-white/10 border border-white/20 hover:bg-white/25 transition-all" onclick="filterByTag('kitchen', this)">Kitchen</button>
                    <button class="px-4 py-2 rounded-xl bg-white/10 border border-white/20 hover:bg-white/25 transition-all" onclick="filterByTag('utility', this)">Utility & fabric</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Category Grid Section -->
    <section class="max-w-container-max mx-auto px-margin-desktop pb-24">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8" id="categories-grid-container">
            <!-- Category Item 1 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.05s;" data-name="refrigerators" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Refrigerators" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBC4M8G9st-Xhy0gJdovBHT_lVb-kP9kfvUM2OPng_nDyGv8drG9r-ZKSaSbaz5hIJ-g9CtoFN_E_V7Wr37Exj-Is_yv9WeGYJB2-1WETDq7JVBT9A6Fc5dmK70eAokoMaVZEMILDHwLVHA3DDB-gVZB6hSYJjvV4abOrZ02uVj3Zq6UiXRXz8ruqlEUcsEFoEe7-0VwCxDa9jdIBJdQYavrjVFDyCcjx1VeIyc_lVnHU24aId2LQAh"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Refrigerators</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">120+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 2 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.1s;" data-name="air conditioners" data-tags="cooling,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Air Conditioners" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA51kQb5fIFfaRGA5clpOOJSdNyXSagFm0w9t13vjYfs6IwUdOsO011zI1rwXuiOypbuNdJ2R3AUW-3MhOB4yaI9E8AXI84ebuV1Ar_yxRKa5WgTE3h8lNIFAZIWhvlTkaEz_XfEkrJuKe__sTRsvrDHGIx31-rcE8zsAPGT9r9PUOE-0rsyjn_KGso9apzEAw69ZcYPR-2mDn51esFrvhjOaDVrGaAYyfjQCRZsbMxI8y5uc512vTh"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Air Conditioners</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">150+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 3 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.15s;" data-name="washing machines washers" data-tags="utility,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Washing Machines" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAdtfk3xbuXvFWCnpfZBagxk2LinQjCU5Qk3kmD0uKVN2d7Mn9GALZVEA7vgqcBc4AkMUtinL9lyvjonhEYFpkPT8cKNqmfMkA14x_5ojoKSKvznlEpI-HBxxj9gXBxQA6fumsWQcvA4jjKOTW8UQ52bi6uEKh41-N5UVbUjy7LTLVDUO77bBAUkG_xYkj65j88iBTrCjDuHUGsMkECMjAAgd5aDuws_0xP8f3DN9P52AM0Gtg2wJmn"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Washing Machines</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">100+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 4 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.2s;" data-name="deep freezers" data-tags="cooling,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Deep Freezers" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuARRUOWMJXNrewaq2fvjbfZnUW_kmI9zktLyeecpBhBWh2-PVSgFnc0ZhKdHKVheHWikXVhKA4a5-VbwqvHXhuvFPZhZqpzuph-D0POXhrn-8UnAF2e5qNP57u-qAQyHMTl6lvyX0nH8YU1HjGHUxIB4pysx9AcT-t6tKr01P3TUeyTIiiXxOXKHdpgzKpDw0dT-AVZCh41Wy4JrGKXzyi3FPkqQV51DyTnAEzg_pW3KIS-JTvsE9xF"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Deep Freezers</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">60+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 5 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.25s;" data-name="water coolers" data-tags="cooling,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Water Coolers" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBpdYEmH5akxZHqsKxq3jM32Zg6P4chDAtRZBh9rpBYynr18lTNTyzkOGNji65LCKmkosQRftEdptvoSj4SibKT84v1p0t3oi9ojbECLPHJRg4HBSHPe0GLCWRTQLTIiUa3zK3fU6RN5Iiaql6inEPq5zH8VWhb_m1g6rYXV3DVy9FnColFTrxiXPaoXEksgAsIS5MEMJv9tQldFMdd2h-SKAtsTWZ881BaLl-OzX5lYNxfI05iEqre"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Water Coolers</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">50+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 6 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.3s;" data-name="kitchen appliances chimneys cooktops" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Kitchen Appliances" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA-A_JP5qbOCpLFOZ6Mt85Rr7-jnUBp6DYH0CikaStvpUl96oV6cOsxfmtQHROJEkwZN3DE3saftj4lYzv-VfULhNsH1XWViSkCW9QKQp0ReqIkGf0iWib8qDjkdYoAHmGRm6CykCj_NIF1pDYYeT37oKbNqm5eeiIvYhUFv2ZTo9JVg7VlYpD40GX2Yg4APTiRo6ioGksIQd1vuWeur0Isv_Qs_cvmJ6lCg7AxW__0CxEifV3lQWoB"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Kitchen Appliances</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">200+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 7 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.35s;" data-name="water purifiers" data-tags="utility,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Water Purifiers" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDIf21_ucFiL-Ml0Ddm8ePv_50Wje7pIohi-ys37wngEl-6rEhPv3L9Eq7TLonne4wuW2TC5a34akzF-yK8kKstxpuompq18ixPgMeEI1sJTM07qM0z920QbjeeTko4AvdMKPopiHS77agpc334oIU_XLPEq69hKQN9Jd4KVgb0d2NyFnk1kAaeRMpmWI0rPwWfdZRjVOrZ1_iukzQfDtJe-uhAdu3KSphl7Kh1tiVaQKxIXaIVG-Cj"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Water Purifiers</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">80+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 8 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.4s;" data-name="microwave ovens microwaves" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Microwave Ovens" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDgQGvf1apRWdKRwSuXafzbo-8AtYDtlJ5DrrS__cBT4QZFsinh__hrXPiHADsF_PcUAm7B083DCs1PJTsg7iS4iexhOK1d9daMke-n82J7yLMg_UZPTlhSOtkirzeZio7QeJzlFYtxTtxYX_yeAMeMDDhvGRzi4dfNthc0zGfNPXxH0Q5m7S0GpkVCWl6Fi-87BSU1N7nKVnnekrfBDVm65WAv1lQ6EHrxhz3R3d1xJLRecwGKoFQN"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Microwave Ovens</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">70+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 9 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.45s;" data-name="dishwashers" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Dishwashers" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAKcWqpcWAi9fWDowMnAZ3omgtFdDo6rVZLzI3OG4PvGLBwtdnGR1WZrfRRhhrFHzd8DEc8zv-qtR7j02qCfjqAtbezwiOfIDhxLSe7UMVQoFnbOTdoaSgC3l7jKo3pqbEqglpZe2M5Od6TSBlz0jGOVXxQr5P9RsnIa4xZbvSgtduPHrWpIeJdkFrmn4HIBIlEQQCJ-aW81j6dGj5_pJREV9_N1Qu25gxQi8XIvIJ8S-5sE1wB26K2"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Dishwashers</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">40+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 10 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.5s;" data-name="small appliances mixers blenders" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Small Appliances" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC35gtArroL4RlWnGCqf88c1ZleG0qcWUoskIbEN5eFzhGBl-lgqOoosGjQr84h2x-F8aCiBXP7oM8K__Dh9aYNddcu0O7CpB4jS85x9C2onwD7BwFSOCcrpCABBgP89zSGMXhm6UVGyT7XRDo6_v9gEPMsnDtqoLJKK0H2cdcJjXbmVyF2ZtGQEAERXpc8Z-KIkxyTH0X1n8mo6dW2M8kE3uqJxKX_I5XrOK1BHkE37J0mGRNXxi6z"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Small Appliances</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">120+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 11 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.55s;" data-name="chimneys hoods" data-tags="kitchen,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Chimneys" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIxxNluqbNZ9uy3c-hx5Prsls0Ru7G__WCTxd83V-Inz5va0vLUacCXHMo6Ead-HPvGkHdwOVSRbGyAelNwbB8plC_Lp_ADbKcolpIgI6aEq1Vbc6cAXNJ3C2tuRqXFJUpG8SLclKMzwV8rj62FcJfPPEQbHP4arUszA5FvTUxs1mlMRgcgJ6e1Ecf4ruKcLUXfezL_sTb6wEqS94kRoYRxOIbow0NNir9xhHJ-pu60IYnauBrOMuk"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Chimneys</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">60+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>

            <!-- Category Item 12 -->
            <div class="category-item-card stagger-fade-in group bg-white rounded-3xl p-6 border border-outline-variant/40 hover:border-primary/50 transition-all duration-300 category-glow-card text-center flex flex-col justify-between" style="animation-delay: 0.6s;" data-name="air coolers coolers" data-tags="cooling,all">
                <div class="bg-surface-container-low rounded-2xl p-6 mb-6 aspect-square flex items-center justify-center overflow-hidden border border-outline-variant/20 group-hover:bg-white transition-colors duration-300">
                    <img alt="Air Coolers" class="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuApybcBGz9xegzbQd5tgMKCa8uIKx2vmiHvbivrfEXn_Lyr-YVwdMVxljoNDNHg8_YfovPUXblpxV0xxp6rAUtABCFCQkd9PM55m3OUiX0SsbWwOHHr0IJroK5ugibJPci7AEQHXwDvZtcgZ5jUW5yEQOnOD-G5tzy5BvB5ingmWiMM4JYOEKM3UCPTAtAgzKx2LrchXE4ewcfISyA3v4VhT1FChHwGneljpGfJVQtLfrcbJu69esAn"/>
                </div>
                <div>
                    <h3 class="font-headline text-lg font-bold text-on-surface group-hover:text-primary transition-colors">Air Coolers</h3>
                    <p class="text-[10px] font-extrabold text-primary uppercase tracking-widest mt-1.5 bg-primary/10 inline-block px-3 py-1 rounded-full border border-primary/10 mb-4">60+ Products</p>
                    <a href="{{ route('dashboard') }}#products" class="flex items-center justify-center gap-1.5 text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors border-t border-outline-variant/10 pt-4 mt-2">
                        Browse Collection <span class="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Interactive Help Banner -->
    <section class="max-w-container-max mx-auto px-margin-desktop pb-24 reveal">
        <div class="bg-primary rounded-[32px] p-10 lg:p-14 flex flex-col lg:flex-row items-center justify-between text-white relative overflow-hidden shadow-2xl border border-white/10">
            <div class="absolute inset-0 opacity-15">
                <div class="w-full h-full" style="background-image: radial-gradient(circle at 2px 2px, white 2px, transparent 0); background-size: 24px 24px;"></div>
            </div>
            
            <div class="z-10 flex flex-col md:flex-row items-center gap-6 mb-8 lg:mb-0">
                <div class="relative">
                    <img alt="Support Agent" class="w-20 h-20 rounded-full border-4 border-white/20 shadow-lg" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAVwOhzDtcpEt188oagiuseB9hZ16T0j5jMzJ6L-EEeCOcebzcMUj6jZoWFsTH7eDqi-QuKUPMIlOIE7sVpR4b3xpb71TJ0spN8r8itKWp1tou2FxequRbGWH2Md8ms4ygsmcXv_7KWWLkx7IvxyNStS4xfkugR-Hdjjs9xXkG6yYiYmvmQTkS0Xq8W8vovdlzP_lMHe2nu74ubfg5XeyhgMfYmTd1RHfOPbwW7rt_LrcMPROqBbN4X"/>
                    <div class="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-primary"></div>
                </div>
                <div class="text-center md:text-left">
                    <h2 class="font-headline text-2xl lg:text-3xl font-extrabold">Need Help Choosing the Right Product?</h2>
                    <p class="text-primary-container text-sm mt-1 font-medium">Get connected to our smart home experts in real-time!</p>
                </div>
            </div>
            
            <div class="z-10 flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
                <button class="bg-white/15 backdrop-blur-md hover:bg-white/25 border border-white/25 text-white font-bold py-3.5 px-8 rounded-xl transition-all flex items-center justify-center gap-2.5 active:scale-95 shadow-sm text-sm cursor-pointer" onclick="alert('Calling HomeKart Expert Hotline...')">
                    <span class="material-symbols-outlined text-lg">call</span>
                    Call Now
                </button>
                <button class="bg-green-500 hover:bg-green-600 text-white font-bold py-3.5 px-8 rounded-xl transition-all flex items-center justify-center gap-2.5 active:scale-95 shadow-md text-sm cursor-pointer" onclick="window.open('https://wa.me/919876543210')">
                    <img alt="WA" class="w-5 h-5 brightness-200" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA9gT4rl7CmtD_zJPJbAX6tux4fbUr-v7vXPIkHDMyGkkMSceav4p7q84-uYsDszzxQqdw1vDq5uqeTz6ZJ_vcSUABZaSgZuvyvLw47f-UKKhhGQO0hz3WgffRDLm2s0AyK7zG86PLkxmr5QuYOu_D9wZ3LWKc6GfpIwqE93TbHHf60s0XMnFhuuXQbHzTuqWQ236bwisuBo3FJ_O68O4OD6-sF3vFagfCv_KbWLxTEaxXSM5J2IaFx"/>
                    Chat on WhatsApp
                </button>
            </div>
        </div>
    </section>

    <!-- Trust Markers Section -->
    <section class="border-t border-outline-variant/30 py-16 bg-surface-container-low reveal">
        <div class="max-w-container-max mx-auto px-margin-desktop grid grid-cols-2 md:grid-cols-5 gap-8 text-center">
            <div>
                <div class="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">verified</span>
                </div>
                <h4 class="text-sm font-bold text-on-surface">100% Genuine</h4>
            </div>
            <div>
                <div class="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">workspace_premium</span>
                </div>
                <h4 class="text-sm font-bold text-on-surface">Brand Warranty</h4>
            </div>
            <div>
                <div class="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">construction</span>
                </div>
                <h4 class="text-sm font-bold text-on-surface">Free Installation</h4>
            </div>
            <div>
                <div class="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">credit_card</span>
                </div>
                <h4 class="text-sm font-bold text-on-surface">Easy EMI</h4>
            </div>
            <div>
                <div class="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">published_with_changes</span>
                </div>
                <h4 class="text-sm font-bold text-on-surface">Exchange Offers</h4>
            </div>
        </div>
    </section>
</main>

<!-- Footer -->
<footer class="w-full bg-inverse-surface text-white pt-20 pb-8">
    <div class="px-margin-desktop max-w-container-max mx-auto">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div class="space-y-6">
                <a class="flex items-center gap-3" href="{{ route('dashboard') }}">
                    <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md">
                        <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                    </div>
                    <span class="font-headline text-2xl font-extrabold tracking-tight">HomeKart</span>
                </a>
                <p class="text-xs text-gray-400 leading-relaxed max-w-xs">
                    Your destination for luxury, energy-efficient smart appliances. Bringing state-of-the-art elegance and intelligence to every home since 2024.
                </p>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Quick Links</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="{{ route('dashboard') }}">Home Store</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">About Our Store</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Careers & Culture</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Store Locator Near Me</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Top Categories</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="#">Luxury Refrigerators</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Split Air Conditioners</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Smart Washers & Laundry</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Water Purifiers</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Store Address</h5>
                <ul class="space-y-3 text-xs text-gray-400">
                    <li class="flex items-start gap-2">
                        <span class="material-symbols-outlined text-sm mt-0.5 text-primary">location_on</span>
                        <span>123, MG Road, Indiranagar, Bengaluru, Karnataka - 560038</span>
                    </li>
                    <li class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-sm text-primary">call</span>
                        <span>+91 98765 43210</span>
                    </li>
                    <li class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-sm text-primary">schedule</span>
                        <span>Mon - Sun: 10:00 AM - 8:00 PM</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="flex flex-col md:flex-row justify-between items-center gap-8 pt-8 border-t border-gray-800">
            <p class="text-xs text-gray-500">© 2026 HomeKart. All rights reserved.</p>
            <div class="flex flex-wrap justify-center gap-8">
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Privacy Policy</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Terms of Service</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<script>
    // Live Search Filtering for Categories with Tags support
    const searchInput = document.getElementById('category-search');
    const cards = document.querySelectorAll('.category-item-card');
    let currentTag = 'all';

    searchInput.addEventListener('input', runFilters);

    function filterByTag(tag, element) {
        currentTag = tag;
        
        // Update active class on tag buttons
        const buttons = document.querySelectorAll('#tag-filters button');
        buttons.forEach(btn => {
            btn.classList.remove('bg-white', 'text-primary');
            btn.classList.add('bg-white/10', 'border', 'border-white/20');
        });
        element.classList.add('bg-white', 'text-primary');
        element.classList.remove('bg-white/10', 'border', 'border-white/20');

        runFilters();
    }

    function runFilters() {
        const query = searchInput.value.toLowerCase().trim();
        
        cards.forEach(card => {
            const nameAttr = card.getAttribute('data-name');
            const tagsAttr = card.getAttribute('data-tags');
            
            const matchesQuery = nameAttr.includes(query);
            const matchesTag = currentTag === 'all' || tagsAttr.includes(currentTag);
            
            if (matchesQuery && matchesTag) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    }

    // Reveal on Scroll Animations
    function reveal() {
        const reveals = document.querySelectorAll(".reveal");
        for (let i = 0; i < reveals.length; i++) {
            const windowHeight = window.innerHeight;
            const elementTop = reveals[i].getBoundingClientRect().top;
            const elementVisible = 100;
            if (elementTop < windowHeight - elementVisible) {
                reveals[i].classList.add("active");
            }
        }
    }
    window.addEventListener("scroll", reveal);
    reveal();
</script>
</body>
</html>
