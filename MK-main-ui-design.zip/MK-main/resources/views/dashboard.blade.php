<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>HomeKart | Premium Home Appliances</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>

    <!-- Vite Assets (Tailwind CSS v4) -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            display: inline-block;
            vertical-align: middle;
        }
        .hero-gradient {
            background: radial-gradient(circle at 80% 20%, rgba(218, 226, 255, 0.4) 0%, rgba(252, 249, 248, 1) 100%);
        }
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        .slider-container {
            position: relative;
            overflow: hidden;
            border-radius: 1.5rem;
        }
        .slider-wrapper {
            display: flex;
            transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .slide {
            min-width: 100%;
        }
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }
    </style>
</head>
<body class="bg-surface text-on-surface font-body overflow-x-hidden antialiased">

<!-- Premium Navigation Bar -->
<header class="fixed top-0 w-full z-50 glass-nav border-b border-outline-variant/40 transition-all duration-300" id="main-header">
    <!-- Main Header -->
    <div class="flex items-center justify-between px-margin-desktop max-w-container-max mx-auto h-20">
        <div class="flex items-center gap-12">
            <a class="flex items-center gap-3 group" href="#">
                <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md group-hover:scale-105 transition-transform">
                    <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                </div>
                <span class="font-headline text-2xl font-extrabold text-primary tracking-tight">HomeKart</span>
            </a>
            
            <!-- Live Search Bar -->
            <div class="hidden lg:flex items-center relative w-[450px]">
                <input id="product-search" class="w-full pl-5 pr-12 py-3 bg-surface-container-low border border-outline-variant/60 rounded-xl focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all text-sm font-medium" placeholder="Search for premium smart appliances..." type="text"/>
                <button class="absolute right-2.5 bg-primary text-on-primary p-2 rounded-xl hover:bg-primary/95 transition-colors shadow-sm">
                    <span class="material-symbols-outlined text-[20px]">search</span>
                </button>
                <!-- Autocomplete Suggestion Dropdown -->
                <div id="search-suggestions" class="absolute top-[56px] left-0 w-full bg-white border border-outline-variant/60 rounded-2xl shadow-xl hidden overflow-hidden z-50 animate-fade-in">
                    <div class="p-3 border-b border-outline-variant/30 text-xs font-bold text-on-surface-variant uppercase tracking-wider">Suggested Products</div>
                    <div class="divide-y divide-outline-variant/20" id="suggestions-list">
                        <!-- Filled by JS -->
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Action Items -->
        <div class="flex items-center gap-8">
            <div class="hidden md:flex items-center gap-2.5 text-primary font-bold bg-primary-fixed/35 px-4 py-2 rounded-xl border border-primary/5">
                <span class="material-symbols-outlined text-lg text-primary">call</span>
                <span class="text-xs font-headline">+91 98765 43210</span>
                <img alt="whatsapp" class="w-5 h-5 ml-1 animate-pulse" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAn9kHDYUKFEgzRQBJpMmsfH72sxUJ-IXcPuukm6CeqTWJONQBiDl0Vag5qro_1pShClp94cSt1x_eUKyyYCQsn1s-vjXzKuh9aspswM6YtcgWaZIPrEPdIZT9bGmwVsB8ftQZ3W65Jo1b1Uzv1jiSyRNJLAuCL9bvOBEvf3flQM4NNem0YNSynIMgYJhWfKsGUbbT4CP8_npk7o7ObdsuXgtRyRACusVJ6Tu3V_X4Cd_Nc-oyuIt2C"/>
            </div>
            
            <div class="flex items-center gap-5">
                <button class="relative p-2.5 text-on-surface-variant hover:text-primary hover:bg-primary-fixed/20 rounded-xl transition-all" onclick="toggleCartDrawer()">
                    <span class="material-symbols-outlined text-2xl">shopping_cart</span>
                    <span id="cart-badge" class="absolute -top-1.5 -right-1.5 bg-secondary text-white text-[10px] font-bold w-5.5 h-5.5 rounded-full flex items-center justify-center border-2 border-white shadow-sm">0</span>
                </button>
                <button class="p-2.5 text-on-surface-variant hover:text-primary hover:bg-primary-fixed/20 rounded-xl transition-all" onclick="alert('Welcome to your premium Wishlist!')">
                    <span class="material-symbols-outlined text-2xl">favorite</span>
                </button>
                
                <!-- Profile Dropdown Button -->
                <div class="relative">
                    <button class="flex items-center gap-2 p-1.5 bg-surface-container-high rounded-full border border-outline-variant/40 hover:border-primary/50 transition-colors" id="profile-dropdown-btn">
                        <div class="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-sm">
                            JD
                        </div>
                        <span class="material-symbols-outlined text-[18px] text-on-surface-variant pr-1">keyboard_arrow_down</span>
                    </button>
                    <!-- Dropdown Menu -->
                    <div id="profile-dropdown" class="absolute right-0 mt-3 w-56 bg-white border border-outline-variant/60 rounded-2xl shadow-xl hidden overflow-hidden z-50 animate-fade-in">
                        <div class="p-4 border-b border-outline-variant/20 bg-surface-container-low">
                            <p class="font-bold text-sm text-on-surface">John Doe</p>
                            <p class="text-xs text-on-surface-variant">john.doe@homekart.com</p>
                        </div>
                        <div class="py-1">
                            <a href="#" class="flex items-center gap-3 px-4 py-2.5 text-sm text-on-surface-variant hover:bg-primary-fixed/25 hover:text-primary transition-colors">
                                <span class="material-symbols-outlined text-lg">person</span> Profile Settings
                            </a>
                            <a href="#" class="flex items-center gap-3 px-4 py-2.5 text-sm text-on-surface-variant hover:bg-primary-fixed/25 hover:text-primary transition-colors">
                                <span class="material-symbols-outlined text-lg">package</span> Order History
                            </a>
                            <hr class="border-outline-variant/20 my-1"/>
                            <a href="{{ url('/') }}" class="flex items-center gap-3 px-4 py-2.5 text-sm text-error hover:bg-error-container/20 transition-colors">
                                <span class="material-symbols-outlined text-lg">logout</span> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Sub Header Navigation -->
    <nav class="hidden lg:flex items-center justify-center gap-10 h-11 border-t border-outline-variant/40 text-xs uppercase tracking-widest font-bold text-on-surface-variant">
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('categories') }}">
            Categories
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="#products">
            Top Sellers
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="#sale">
            Offers & Sales
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="#brands">
            Partner Brands
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
    </nav>
</header>

<main class="pt-32">
    <!-- Hero Slider Section -->
    <section class="hero-gradient py-10 reveal active">
        <div class="max-w-container-max mx-auto px-margin-desktop grid grid-cols-1 lg:grid-cols-12 items-center gap-12">
            <!-- Text Content -->
            <div class="lg:col-span-5 space-y-6">
                <span class="bg-primary/10 text-primary border border-primary/20 px-4 py-1.5 rounded-full font-bold text-xs uppercase tracking-widest inline-block shadow-sm">
                    Luxury Smart Living
                </span>
                <h1 class="font-headline text-5xl lg:text-[56px] leading-[1.1] font-extrabold text-on-surface tracking-tight">
                    Upgrade Your Home<br/><span class="text-primary bg-gradient-to-r from-primary to-primary-container bg-clip-text text-transparent">Upgrade Your Life</span>
                </h1>
                <p class="font-sans text-on-surface-variant text-base lg:text-lg max-w-lg leading-relaxed">
                    Discover a handpicked collection of energy-efficient smart appliances engineered for modern luxury.
                </p>
                <div class="flex gap-4 pt-2">
                    <a href="#products" class="bg-primary text-on-primary px-8 py-3.5 rounded-xl font-bold hover:shadow-xl hover:bg-primary-container hover:text-on-primary-container transition-all flex items-center gap-2 group">
                        Explore Collection
                        <span class="material-symbols-outlined text-lg group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </a>
                </div>
            </div>
            
            <!-- Interactive Slider -->
            <div class="lg:col-span-7 relative slider-container shadow-2xl border border-white/20">
                <div class="slider-wrapper" id="hero-slider">
                    <!-- Slide 1 -->
                    <div class="slide relative">
                        <img alt="Premium Appliances Display 1" class="w-full h-[450px] object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDbFgBDI8fem0ekibaQ5BJ8aimNq8hmf43acrAfPDYejd3f8zsiQZ5pwgYcFNp5wbZmt5t08HEZWCw4CL-y4kAZuzSFEZDPLUSbX0IGEaTMSQLPWlfexU2HNpGYcD4Fu_RsSUqQrnum-WlxZPrCSliHjooETzSIegHzp5eL0r-7PAgouDvuC09DCkleNPj8K-7G2GcsvwJQglRsg1UqlIdsAfkw7xG78G8xQ7R62XL2mE5p__9mayre"/>
                        <div class="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
                            <span class="text-xs uppercase tracking-widest text-primary-fixed font-bold">Smart Kitchen Showcase</span>
                            <h3 class="text-xl font-bold mt-1">Sleek Integrated Workspaces</h3>
                        </div>
                    </div>
                    <!-- Slide 2 -->
                    <div class="slide relative">
                        <img alt="Premium Kitchen Appliances" class="w-full h-[450px] object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBcsVyS6aD4KotNWVRAWMOKxls1MZM5K5D-fcURn2NtpwG5l1q0gyCrOWijNRKcFyihBrzLTP2C8XxTLTaOmCFLPnTOrciDngxebIHdeTAfmaMqudfG3KJMWE6LquLuD_IrdqQvlzbqx73822MNsNiiVK14ebItx44dh4yUyOtpzg8FdHqeXn2OhOh85m4NwQwL0nTMVnb7iqMiL1aqmPM9NCKDE_tMp3CzHa6FWP4WF_t5NrbmOOsD"/>
                        <div class="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
                            <span class="text-xs uppercase tracking-widest text-primary-fixed font-bold">Premium Cooktops & Hoods</span>
                            <h3 class="text-xl font-bold mt-1">Professional Grade Cooking Ranges</h3>
                        </div>
                    </div>
                    <!-- Slide 3 -->
                    <div class="slide relative">
                        <img alt="Modern Laundry Setup" class="w-full h-[450px] object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAjLfFP5hBAUPm-qDSWPH0xN6W47HY8Oey5vccjyMZwVZVpUW0Y4VZAOtmAkhTslFB1wfQ8tuakZl9wpTQd5T6gZ1tGV34K5soX2qRYZwni0qRxtaDQtLHjp6UdiFeqbsRhywMObGJV7keapXT4d46GyeCuJwuijQ7cDeklm9Kssd9Zcgsx9gKHZsjVEzAytj8q53O6mnCvqaSAdXwMyyBz_WG9z21Sr8myYsPnkqj0uXLoKWRiTQer"/>
                        <div class="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/85 via-black/40 to-transparent text-white">
                            <span class="text-xs uppercase tracking-widest text-primary-fixed font-bold">Intelligent Washers</span>
                            <h3 class="text-xl font-bold mt-1">Fabric Care Redefined with AI Direct Drive</h3>
                        </div>
                    </div>
                </div>
                <!-- Slider Controls -->
                <div class="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-3 z-10" id="slider-dots">
                    <button class="w-3 h-3 rounded-full bg-white transition-all scale-125" data-index="0"></button>
                    <button class="w-3 h-3 rounded-full bg-white/50 transition-all" data-index="1"></button>
                    <button class="w-3 h-3 rounded-full bg-white/50 transition-all" data-index="2"></button>
                </div>
            </div>
        </div>
        
        <!-- Trust Badges -->
        <div class="max-w-container-max mx-auto px-margin-desktop mt-12 grid grid-cols-2 md:grid-cols-4 gap-6 border-t border-outline-variant/20 pt-8">
            <div class="flex items-center gap-4 bg-white/60 p-4 rounded-2xl border border-outline-variant/35 backdrop-blur-sm hover:shadow-md transition-shadow">
                <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">verified</span>
                </div>
                <div>
                    <h4 class="text-sm font-bold text-on-surface">100% Genuine</h4>
                    <p class="text-xs text-on-surface-variant">Authorized Brand Warranty</p>
                </div>
            </div>
            <div class="flex items-center gap-4 bg-white/60 p-4 rounded-2xl border border-outline-variant/35 backdrop-blur-sm hover:shadow-md transition-shadow">
                <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">payments</span>
                </div>
                <div>
                    <h4 class="text-sm font-bold text-on-surface">Best Price Guarantee</h4>
                    <p class="text-xs text-on-surface-variant">Match & Match Options</p>
                </div>
            </div>
            <div class="flex items-center gap-4 bg-white/60 p-4 rounded-2xl border border-outline-variant/35 backdrop-blur-sm hover:shadow-md transition-shadow">
                <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">support_agent</span>
                </div>
                <div>
                    <h4 class="text-sm font-bold text-on-surface">Expert Support 24/7</h4>
                    <p class="text-xs text-on-surface-variant">Free Setup & Installation</p>
                </div>
            </div>
            <div class="flex items-center gap-4 bg-white/60 p-4 rounded-2xl border border-outline-variant/35 backdrop-blur-sm hover:shadow-md transition-shadow">
                <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-2xl font-bold">credit_card</span>
                </div>
                <div>
                    <h4 class="text-sm font-bold text-on-surface">Easy EMI Plans</h4>
                    <p class="text-xs text-on-surface-variant">No Cost EMI & Card Offers</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Shop by Categories Section -->
    <section id="categories" class="py-20 px-margin-desktop max-w-container-max mx-auto reveal">
        <div class="flex justify-between items-end mb-12">
            <div>
                <span class="text-xs font-bold text-primary tracking-widest uppercase">Browse Our Categories</span>
                <h2 class="font-headline text-3xl font-extrabold mt-1 text-on-surface">Shop by Categories</h2>
            </div>
            <a class="text-primary text-xs font-bold hover:underline flex items-center gap-1.5 uppercase tracking-widest" href="{{ route('categories') }}">
                View All Categories
                <span class="material-symbols-outlined text-sm">open_in_new</span>
            </a>
        </div>
        
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-6">
            <!-- Category Item 1 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Refrigerators" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBi_Jk1hWsAzICHhZcxP08P7FK3qjH9fCIuzLGBpUojxJU4vea7MM9jItFwbNCjunj12iqBeGjE0rL8RTvEc1YczQMbv_5HFPyzHqvUYX3OnY15-UlXhzfuOFiX5OSjF8LyFs1WVO0eKGXxaIKvM-TDByA2BaZi19I5WDKI6IJ2bJcJhy2sYVEZBcwUSGY4vsYdncrKglOyTxssXJB-2ey0lp7ZS7zWLt7J_gzYaGMZngzcpoXlYhRc"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Refrigerators</span>
            </a>
            
            <!-- Category Item 2 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Air Conditioners" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuADpqcS8OZQhhgknL-XkQBBG9sHycLonyr-RxbC_Im5UoibFXwK6GpV5-Vtb1sntddaNmyb4xoam0EkhIJCe24QTUDA_aOTwVAtOHu1rt40r54baTejZccy5W2Uas0nHFxfbeZnPkVcwzr56nf_RhVLsYp_GMNCrZ19UkTRdWTlDbdAIKGPU2OHxVp6bzBSeTkXBhp1lBAvYCPjyEIyMyjc2bcuqq1JQOIY016bLlwliHjLzKZH9ICq"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Air Conditioners</span>
            </a>
            
            <!-- Category Item 3 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Washing Machines" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBYFVObpst0-T18Zg6GZLLZ-7-NRDDbEzJLWhfEvqcwEQLIQF-znIphauZbwp4ou6AB7uF6Jm_auCiIHGo6Ba2yaesX3mVgS5olguzb3GPsbRrEEb5OQdMCkTV8GngxmQXgryrOzZj8FH9FHMp64_Cntpc-2gd_zA0J9KuTlPfLpPEkOksrqEhG0-3yS2exv5vHKrY1UFnSfE2dOZlXg4BU1CZp1WJNl7Jnhhd9TNu4G2LrYNhPGNns"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Washers</span>
            </a>

            <!-- Category Item 4 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Microwaves" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA_8hlnlHq5SOjpUq6-TD_S8H8Alo_rfMkV1g5HpWS53vdre87f5kzAlYNZRf8MKSfer-qbAxB8E0e5ob1YlYgTRvYbAKpLuITRSH6lslkfis42gneOG5QX-VXo8lZ6AUY27okoeEv0KOhGwZ2XrPglcruSR5IX4PVlHCdEC-vltwCuFCMFLXTpVuiKu7mNiFu6U1u7sQL8xrsokeyPGRS5AKX0QXTwJ83tpFGEOX3jy9WIOxeqKy91"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Microwaves</span>
            </a>

            <!-- Category Item 5 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Chimneys" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBSdAE9X84ieeARxbK6hdFyOGuCdJUYi1fKbxXyiHeZxqndMycx5sam9zgIzskg_qpdcPwxkMTyjOzqb3ISQlIgO3EA-KOZ_nVdfWfAL_fbnz2I6_GnSB_26TWkLq2HaM3dMq2t7FpWOmTN4zJO74PRHbfITRrvxz3z7JCkIJa-zs4d5X2Zn96NSGP19kODpasj9qNxr91UlE1dpyyoVFzEDf4a7cnn3XVsVLykKEwmaKRPnRT2-fhl"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Chimneys</span>
            </a>

            <!-- Category Item 6 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center overflow-hidden p-3 group-hover:scale-110 transition-transform">
                    <img alt="Small Appliances" class="w-full h-full object-contain" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB53GTCYT9PhHh5kkUOS0wjxd6ZbUALOjpMeIdXSB_a8HYPq5hPweKK_Hx9Rw0SD82b1e_jJcAiWilu_r1rlQd0i5D4CaDhTD0rVn8Sdy975sXiq9g682OsCCQE5iyWZzfABth2BWex1HN83MxjudLrl5ocZd98J4UYn2ayS1fFVaVdvSTl5CKlBpZC3IBZTGzDwn2WivFuBTnM953nR5fV1j0WTjn9UxdsYsMMca-QO10_YVkupSMn"/>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Kitchenware</span>
            </a>

            <!-- Category Item 7 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined text-3xl text-primary font-bold">water_drop</span>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Water Purifiers</span>
            </a>

            <!-- Category Item 8 -->
            <a class="group bg-white rounded-2xl p-5 border border-outline-variant/40 hover:border-primary flex flex-col items-center gap-4 transition-all duration-300 hover:shadow-lg" href="#">
                <div class="w-20 h-20 rounded-full bg-surface-container-low flex items-center justify-center group-hover:scale-110 transition-transform">
                    <span class="material-symbols-outlined text-3xl text-primary font-bold">ac_unit</span>
                </div>
                <span class="text-xs font-bold text-on-surface-variant group-hover:text-primary transition-colors text-center">Deep Freezers</span>
            </a>
        </div>
    </section>

    <!-- Top Selling Products Section -->
    <section id="products" class="bg-surface-container-low py-20 reveal">
        <div class="max-w-container-max mx-auto px-margin-desktop">
            <div class="flex justify-between items-end mb-12">
                <div>
                    <span class="text-xs font-bold text-primary tracking-widest uppercase">Popular Choices</span>
                    <h2 class="font-headline text-3xl font-extrabold mt-1 text-on-surface">Top Selling Products</h2>
                </div>
                <a class="text-primary text-xs font-bold hover:underline flex items-center gap-1.5 uppercase tracking-widest" href="#">
                    View All Products
                    <span class="material-symbols-outlined text-sm">open_in_new</span>
                </a>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter" id="product-grid">
                <!-- Product Card 1 -->
                <div class="bg-white rounded-2xl border border-outline-variant/40 overflow-hidden hover:shadow-2xl hover:border-primary/30 transition-all flex flex-col group relative" data-id="1">
                    <div class="absolute top-4 left-4 z-10">
                        <span class="bg-secondary text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">Bestseller</span>
                    </div>
                    <div class="relative p-6 bg-white aspect-square flex items-center justify-center overflow-hidden">
                        <img alt="LG Refrigerator" class="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 cursor-pointer" onclick="window.location.href='{{ route('product.detail', 1) }}'" src="https://lh3.googleusercontent.com/aida-public/AB6AXuClOlCi6rigCXtuQL7CRGTW7VPc7blm7Q_SwSi2sJD_bsSvatTRCpgUg_QLk9GdOLLbpVtOleXbmtriUNw23fXE-nu3CWrYL2u3j8bKqsugHMHCijmf_0UvcTyLBPjK8fQ_CDFdISlMs5uYdhDhSXJq4x489ZISKB0dqfuhEawngrtk_U1QuuYFJrPJXdzKpMr_flVCILtZ9xlZKhZyVVZFc2M9YAbCivZARzqpcq6em8XQ2jitJ22S"/>
                        <button class="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white hover:text-red-500 transition-colors text-on-surface-variant" onclick="toggleWishlist(1, this)">
                            <span class="material-symbols-outlined text-[20px]">favorite</span>
                        </button>
                    </div>
                    <div class="p-6 flex-1 flex flex-col bg-surface-container-lowest border-t border-outline-variant/20">
                        <div class="flex items-center gap-1.5 mb-2">
                            <span class="text-secondary text-xs">★★★★★</span>
                            <span class="text-[11px] text-on-surface-variant font-bold">(4.6 / 708 reviews)</span>
                        </div>
                        <h3 class="font-bold text-on-surface text-base mb-1 leading-snug group-hover:text-primary transition-colors cursor-pointer" onclick="window.location.href='{{ route('product.detail', 1) }}'">LG Double Door Refrigerator GL-B251TDSY</h3>
                        <p class="text-xs text-on-surface-variant mb-5">260L, 3 Star, Smart Inverter Compressor, Shiny Steel</p>
                        <div class="mt-auto flex items-center justify-between">
                            <div>
                                <span class="text-xl font-extrabold text-primary">₹32,990</span>
                                <span class="block text-xs text-on-surface-variant line-through font-medium">₹38,990</span>
                            </div>
                            <button class="bg-primary text-on-primary p-3 rounded-xl hover:bg-primary/95 transition-colors shadow-md flex items-center justify-center" onclick="addToCart(1, 'LG Double Door Refrigerator GL-B251TDSY', 32990, 'https://lh3.googleusercontent.com/aida-public/AB6AXuClOlCi6rigCXtuQL7CRGTW7VPc7blm7Q_SwSi2sJD_bsSvatTRCpgUg_QLk9GdOLLbpVtOleXbmtriUNw23fXE-nu3CWrYL2u3j8bKqsugHMHCijmf_0UvcTyLBPjK8fQ_CDFdISlMs5uYdhDhSXJq4x489ZISKB0dqfuhEawngrtk_U1QuuYFJrPJXdzKpMr_flVCILtZ9xlZKhZyVVZFc2M9YAbCivZARzqpcq6em8XQ2jitJ22S')">
                                <span class="material-symbols-outlined text-[20px]">add_shopping_cart</span>
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Product Card 2 -->
                <div class="bg-white rounded-2xl border border-outline-variant/40 overflow-hidden hover:shadow-2xl hover:border-primary/30 transition-all flex flex-col group relative" data-id="2">
                    <div class="relative p-6 bg-white aspect-square flex items-center justify-center overflow-hidden">
                        <img alt="LG Washer" class="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 cursor-pointer" onclick="window.location.href='{{ route('product.detail', 2) }}'" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBcsVyS6aD4KotNWVRAWMOKxls1MZM5K5D-fcURn2NtpwG5l1q0gyCrOWijNRKcFyihBrzLTP2C8XxTLTaOmCFLPnTOrciDngxebIHdeTAfmaMqudfG3KJMWE6LquLuD_IrdqQvlzbqx73822MNsNiiVK14ebItx44dh4yUyOtpzg8FdHqeXn2OhOh85m4NwQwL0nTMVnb7iqMiL1aqmPM9NCKDE_tMp3CzHa6FWP4WF_t5NrbmOOsD"/>
                        <button class="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white hover:text-red-500 transition-colors text-on-surface-variant" onclick="toggleWishlist(2, this)">
                            <span class="material-symbols-outlined text-[20px]">favorite</span>
                        </button>
                    </div>
                    <div class="p-6 flex-1 flex flex-col bg-surface-container-lowest border-t border-outline-variant/20">
                        <div class="flex items-center gap-1.5 mb-2">
                            <span class="text-secondary text-xs">★★★★☆</span>
                            <span class="text-[11px] text-on-surface-variant font-bold">(4.5 / 94 reviews)</span>
                        </div>
                        <h3 class="font-bold text-on-surface text-base mb-1 leading-snug group-hover:text-primary transition-colors cursor-pointer" onclick="window.location.href='{{ route('product.detail', 2) }}'">LG AI Direct Drive Washer</h3>
                        <p class="text-xs text-on-surface-variant mb-5">8kg, Front Load, Smart Thinq AI fabric sensing</p>
                        <div class="mt-auto flex items-center justify-between">
                            <div>
                                <span class="text-xl font-extrabold text-primary">₹32,490</span>
                                <span class="block text-xs text-on-surface-variant line-through font-medium">₹42,000</span>
                            </div>
                            <button class="bg-primary text-on-primary p-3 rounded-xl hover:bg-primary/95 transition-colors shadow-md flex items-center justify-center" onclick="addToCart(2, 'LG AI Direct Drive Washer', 32490, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBcsVyS6aD4KotNWVRAWMOKxls1MZM5K5D-fcURn2NtpwG5l1q0gyCrOWijNRKcFyihBrzLTP2C8XxTLTaOmCFLPnTOrciDngxebIHdeTAfmaMqudfG3KJMWE6LquLuD_IrdqQvlzbqx73822MNsNiiVK14ebItx44dh4yUyOtpzg8FdHqeXn2OhOh85m4NwQwL0nTMVnb7iqMiL1aqmPM9NCKDE_tMp3CzHa6FWP4WF_t5NrbmOOsD')">
                                <span class="material-symbols-outlined text-[20px]">add_shopping_cart</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product Card 3 -->
                <div class="bg-white rounded-2xl border border-outline-variant/40 overflow-hidden hover:shadow-2xl hover:border-primary/30 transition-all flex flex-col group relative" data-id="3">
                    <div class="relative p-6 bg-white aspect-square flex items-center justify-center overflow-hidden">
                        <img alt="Whirlpool AC" class="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 cursor-pointer" onclick="window.location.href='{{ route('product.detail', 3) }}'" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBcFfi4uqYwbjcVCNOtgEojoCerxCAxAwGMNFWjlG4wQ5LO3mWW-s7Zm5KzEfRKTv62hia_9UbvkXrOVmsRqJYmZZq9rPg6NL8bTace1uFRCNCecB1h-hUvO5qVmPUKEvCK0DvCpYyrG8tT4qkZazDZbEQu0F3h_PpAfSD6aFolvNuF8Pqv62MUPn7ZVTe6mYmGlbet28nZusmlxLu9XReGY6unuars_pleFNQfEow3xBium0J5uRzA"/>
                        <button class="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white hover:text-red-500 transition-colors text-on-surface-variant" onclick="toggleWishlist(3, this)">
                            <span class="material-symbols-outlined text-[20px]">favorite</span>
                        </button>
                    </div>
                    <div class="p-6 flex-1 flex flex-col bg-surface-container-lowest border-t border-outline-variant/20">
                        <div class="flex items-center gap-1.5 mb-2">
                            <span class="text-secondary text-xs">★★★★★</span>
                            <span class="text-[11px] text-on-surface-variant font-bold">(4.9 / 210 reviews)</span>
                        </div>
                        <h3 class="font-bold text-on-surface text-base mb-1 leading-snug group-hover:text-primary transition-colors cursor-pointer" onclick="window.location.href='{{ route('product.detail', 3) }}'">Whirlpool 1.5 Ton Split AC</h3>
                        <p class="text-xs text-on-surface-variant mb-5">5 Star, Dual Inverter, Copper Condenser, 6th Sense Cool</p>
                        <div class="mt-auto flex items-center justify-between">
                            <div>
                                <span class="text-xl font-extrabold text-primary">₹43,990</span>
                                <span class="block text-xs text-on-surface-variant line-through font-medium">₹55,000</span>
                            </div>
                            <button class="bg-primary text-on-primary p-3 rounded-xl hover:bg-primary/95 transition-colors shadow-md flex items-center justify-center" onclick="addToCart(3, 'Whirlpool 1.5 Ton Split AC', 43990, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBcFfi4uqYwbjcVCNOtgEojoCerxCAxAwGMNFWjlG4wQ5LO3mWW-s7Zm5KzEfRKTv62hia_9UbvkXrOVmsRqJYmZZq9rPg6NL8bTace1uFRCNCecB1h-hUvO5qVmPUKEvCK0DvCpYyrG8tT4qkZazDZbEQu0F3h_PpAfSD6aFolvNuF8Pqv62MUPn7ZVTe6mYmGlbet28nZusmlxLu9XReGY6unuars_pleFNQfEow3xBium0J5uRzA')">
                                <span class="material-symbols-outlined text-[20px]">add_shopping_cart</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Product Card 4 -->
                <div class="bg-white rounded-2xl border border-outline-variant/40 overflow-hidden hover:shadow-2xl hover:border-primary/30 transition-all flex flex-col group relative" data-id="4">
                    <div class="relative p-6 bg-white aspect-square flex items-center justify-center overflow-hidden">
                        <img alt="Bosch Dishwasher" class="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 cursor-pointer" onclick="window.location.href='{{ route('product.detail', 4) }}'" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBMBNxw847iHFfMt61eiiunBmAb71SkcjJtq8-doyUaTJn-01R6WoYqxHn4qE_l2a2xQy2uRvbEOGkprWCBczFPL1SI-MTWDGWZeuk6dfdhzfTHviLmuiYW6428OKQ53OXdVMQ3MIal1ID73z8Umf9-6MxfHEUZkNZUDpww4Xkg_iaqO9NMevDSMkNVh0Fyg2i_M652znNC4skgCULFTtkx9QTYAuRbyPxH4PhiNURTZhTijd9xL3Ex"/>
                        <button class="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white hover:text-red-500 transition-colors text-on-surface-variant" onclick="toggleWishlist(4, this)">
                            <span class="material-symbols-outlined text-[20px]">favorite</span>
                        </button>
                    </div>
                    <div class="p-6 flex-1 flex flex-col bg-surface-container-lowest border-t border-outline-variant/20">
                        <div class="flex items-center gap-1.5 mb-2">
                            <span class="text-secondary text-xs">★★★★☆</span>
                            <span class="text-[11px] text-on-surface-variant font-bold">(4.7 / 138 reviews)</span>
                        </div>
                        <h3 class="font-bold text-on-surface text-base mb-1 leading-snug group-hover:text-primary transition-colors cursor-pointer" onclick="window.location.href='{{ route('product.detail', 4) }}'">Bosch 13 Place Dishwasher</h3>
                        <p class="text-xs text-on-surface-variant mb-5">Free Standing, Intensive Kadhai mode, super silent</p>
                        <div class="mt-auto flex items-center justify-between">
                            <div>
                                <span class="text-xl font-extrabold text-primary">₹52,990</span>
                                <span class="block text-xs text-on-surface-variant line-through font-medium">₹62,000</span>
                            </div>
                            <button class="bg-primary text-on-primary p-3 rounded-xl hover:bg-primary/95 transition-colors shadow-md flex items-center justify-center" onclick="addToCart(4, 'Bosch 13 Place Dishwasher', 52990, 'https://lh3.googleusercontent.com/aida-public/AB6AXuBMBNxw847iHFfMt61eiiunBmAb71SkcjJtq8-doyUaTJn-01R6WoYqxHn4qE_l2a2xQy2uRvbEOGkprWCBczFPL1SI-MTWDGWZeuk6dfdhzfTHviLmuiYW6428OKQ53OXdVMQ3MIal1ID73z8Umf9-6MxfHEUZkNZUDpww4Xkg_iaqO9NMevDSMkNVh0Fyg2i_M652znNC4skgCULFTtkx9QTYAuRbyPxH4PhiNURTZhTijd9xL3Ex')">
                                <span class="material-symbols-outlined text-[20px]">add_shopping_cart</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Promotional Banner Section -->
    <section id="sale" class="py-20 px-margin-desktop max-w-container-max mx-auto reveal">
        <div class="relative rounded-[32px] overflow-hidden bg-primary h-[380px] flex flex-col md:flex-row items-center shadow-2xl border border-white/10">
            <div class="absolute inset-0 opacity-15">
                <div class="w-full h-full" style="background-image: radial-gradient(circle at 2px 2px, white 2px, transparent 0); background-size: 24px 24px;"></div>
            </div>
            
            <div class="relative z-10 p-12 md:w-1/2 space-y-6">
                <span class="bg-secondary-container text-on-secondary-container text-[11px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">Limited Period Offer</span>
                <h2 class="text-white font-headline text-4xl lg:text-5xl leading-tight font-extrabold">Summer Cooling<br/>Mega Sale</h2>
                <p class="text-white/85 font-sans text-sm lg:text-base max-w-sm">Up to 40% OFF on premium Air Conditioners, Deep Freezers, and smart purifiers. Free fast delivery.</p>
                <button class="bg-secondary-container text-on-secondary-container px-8 py-3.5 rounded-xl font-bold hover:shadow-xl hover:opacity-95 transition-all uppercase tracking-widest text-xs">
                    Shop the Sale
                </button>
            </div>
            
            <div class="relative h-full md:w-1/2 flex justify-end items-end p-8 overflow-hidden">
                <img alt="Cooling Appliances Sale" class="h-[120%] object-contain transform translate-y-12 drop-shadow-2xl" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDUmbq_UCkT8ShEFqdA8jxV5iJrBjj8mSIkELhWlBwB8u_bQzkvMGwWianxwSdu_OBGzFHnAGoiLUnEWEbpBCVKYwWWbOLzMcEe1pugMa0sVZ2mqzyOtcxFMjiHTbEuRPCm2JIevR8Z7So3gLSNHAGZSQfiehhSOl3HUZstrEsPlL8tRSf7FXT61g6k40Edrb6f49oelZVx37bg-MPSwXxqOwFpxBC8r_Dc93h5CEaLdn2y9v91YYyN"/>
            </div>
        </div>
    </section>

    <!-- Trusted Partners Brands Section -->
    <section id="brands" class="py-16 border-t border-outline-variant/30 reveal">
        <div class="max-w-container-max mx-auto px-margin-desktop">
            <h3 class="text-center text-xs font-bold text-on-surface-variant mb-12 uppercase tracking-[0.25em]">Our Trusted Premium Partners</h3>
            <div class="flex flex-wrap justify-center items-center gap-12 lg:gap-16 opacity-50 hover:opacity-100 transition-opacity duration-300">
                <img alt="Samsung" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA7Eqs1iDggcHvO_yUFWwvSO1ohcfWpr160mCv20qcz03ZfeI-m1hTYfV6cK-VXfqerZCPpclICLJH236KZVUHihYFfhdV2C252_1yhFGA658EI2gOCz0xw7x7q8NwepwB-_Kzra2RMSEgycXT7RsI7Br2OebZEj_vuCdZjEj8Escmliua4JuNNLRfpFqkwrc0lD3DsYwG1ZqZdUiGrm8O3aKHoToOt8UqIVpGbJK-cSOsON9xl0rMZ"/>
                <img alt="LG" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCq_HqZA-gMUCbPhcq5KHky6qVroswd9pUWFoc3xuxeW4byhuNyuL_11zboYX9RYpSAT2scXM8ynV15kYqrIAxf9YZWMXh2m3F5SzjcMUKKIFGGW3d-uokoVXuf14oGDr9PJg621ouMoxzBllmP1PAh6bpLgMmVUFBctWTfi_se7XFnhHZp2DBkpO0zRvnftb_qd4Dpbwlwx33eQCVFW6558ZJY6wL-5AXe6dQfsufSAG08C5kjQAeN"/>
                <img alt="Whirlpool" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCELxphHUaWxF3ygDq6saeijInDB8moP_CTLJJKXnK6CVdpA8dZhxJ4RCcAoAv9Tsbe_Iu5nz1Ris4_EURMTZvuntaqLEAkao0coFn_vDsZnYsMKWA141kk25kBiK6g9H5tYX2YQs1TzH2a30OScPZAJQXHPu58gyg1j_II0U5n0C3-QCMOdqmsMUEU4VnsY2qXEGPxaRgqb5fOIbhctqIxGZIjT_jiIz7LTuRorGJlnMykSbrErTLE"/>
                <img alt="Bosch" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC045suBPIoGgKNZ4t5CPjNrOXHRJifJbEkKY39Y6F_ypliuxvaxmVSSohnIfHv4sf1j1N0wGjXh1SMLeMP1BDgtrJW7V9jdncgyR9TcrvFFoGsb8y3zB6SmlhzALrCPEKlaWxu2AUfvVJiDe0vpo0Uf8Bzvgp1rMvV-dMaQUc7PeHz8mJXyVINK9xdznfQ7fSPQA-hk_f2wAKlgPjR2S5TIHKxTYwMVCDq4KRt-nJmZzBKLvcCB3UY"/>
                <img alt="Panasonic" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDpFONxERAitw1wjq7nYPrzEBT3f5zPwajhWTpCw0w_gMhsEhAqrG3JiWM-uGlrS84iWtRFR4hOFz_dct5DGGLl9L04lfTQNphBr6C6WBeQC8C1HkZBX8bRsvgFybNoewHzNihUjlYBftvlqxPN3MqOOTR8ggnBkcC3vnHVWhf-qdsL8nWnJomv_mb9zkdHxIzYPp-iNI9OIzZpyqGRTrzPA0CZI0FLHVTB0QlVW_iKrJP_sIni7S6x"/>
                <img alt="Haier" class="h-6 lg:h-8 grayscale hover:grayscale-0 hover:scale-105 transition-all" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCahajT_at9Ys2gdYujTyEqeXVukyJ2JDvXXFT0TwzqCEVFPQA8Eld7nLz_8fsFUWMV_wPH_AbQzhjdpBLJLViynkEm2AjWlR40nSWLwLUJfxUjWaIp2qCCSfpxms1QxCXvzpG5cWrvmOwa4BL1p6P3Y1iA08J5_kq1_utOVBqa8vwvC5B18g35Osp-WLFBWSWm2itNUjg_BR_y7Wp3SzA_mjB_NrqYwYWSzNyN8RfVH4zcBTniMGCD"/>
            </div>
        </div>
    </section>
</main>

<!-- Shopping Cart Slide-out Drawer -->
<div id="cart-drawer" class="fixed inset-0 z-50 pointer-events-none hidden">
    <!-- Overlay backdrop -->
    <div id="cart-overlay" class="absolute inset-0 bg-black/50 opacity-0 transition-opacity duration-300 pointer-events-auto" onclick="toggleCartDrawer()"></div>
    <!-- Drawer panel -->
    <div id="cart-panel" class="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl flex flex-col translate-x-full transition-transform duration-300 pointer-events-auto">
        <div class="p-6 border-b border-outline-variant/30 flex justify-between items-center bg-surface-container-low">
            <div class="flex items-center gap-3">
                <span class="material-symbols-outlined text-primary text-2xl">shopping_bag</span>
                <h3 class="font-headline text-lg font-bold">Your Premium Cart</h3>
            </div>
            <button class="p-1 rounded-lg hover:bg-surface-container-high transition-colors" onclick="toggleCartDrawer()">
                <span class="material-symbols-outlined">close</span>
            </button>
        </div>
        
        <!-- Cart Items list -->
        <div class="flex-1 overflow-y-auto p-6 space-y-6" id="cart-items-container">
            <!-- Filled dynamically by JS -->
            <div class="text-center py-20 text-on-surface-variant space-y-4" id="empty-cart-message">
                <span class="material-symbols-outlined text-5xl opacity-40">shopping_cart_off</span>
                <p class="text-sm font-medium">Your shopping cart is currently empty.</p>
                <button class="bg-primary text-on-primary px-5 py-2 rounded-xl text-xs font-bold" onclick="toggleCartDrawer()">Continue Shopping</button>
            </div>
        </div>
        
        <!-- Checkout Footer -->
        <div class="p-6 border-t border-outline-variant/30 bg-surface-container-lowest space-y-4">
            <div class="flex justify-between items-center font-headline">
                <span class="text-sm font-bold text-on-surface-variant">Subtotal</span>
                <span id="cart-subtotal" class="text-lg font-extrabold text-primary">₹0</span>
            </div>
            <p class="text-[11px] text-on-surface-variant">Shipping and taxes will be calculated at checkout.</p>
            <button class="w-full bg-primary text-on-primary py-3.5 rounded-xl font-bold hover:bg-primary/95 transition-all shadow-md uppercase tracking-wider text-xs" onclick="alert('Proceeding to secure checkout!')">
                Proceed to Secure Checkout
            </button>
        </div>
    </div>
</div>

<!-- Product Quick View Modal -->
<div id="product-modal" class="fixed inset-0 z-50 flex items-center justify-center hidden">
    <!-- Backdrop -->
    <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="closeProductModal()"></div>
    <!-- Modal Content -->
    <div class="relative bg-white w-full max-w-3xl rounded-3xl overflow-hidden shadow-2xl z-10 border border-outline-variant/30 m-4 flex flex-col md:flex-row">
        <!-- Close Button -->
        <button class="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-colors" onclick="closeProductModal()">
            <span class="material-symbols-outlined text-xl">close</span>
        </button>
        
        <!-- Image Section -->
        <div class="md:w-1/2 bg-surface-container-low p-8 flex items-center justify-center aspect-square md:aspect-auto">
            <img id="modal-image" alt="Product Image" class="max-h-64 md:max-h-80 object-contain w-full" src=""/>
        </div>
        
        <!-- Info Section -->
        <div class="md:w-1/2 p-8 flex flex-col justify-between">
            <div class="space-y-4">
                <span id="modal-tag" class="bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider inline-block">HomeKart Exclusive</span>
                <h2 id="modal-title" class="font-headline text-2xl font-bold text-on-surface leading-tight">Product Title</h2>
                <div class="flex items-center gap-1.5">
                    <span class="text-secondary text-sm">★★★★★</span>
                    <span id="modal-rating" class="text-xs text-on-surface-variant font-bold">(4.8 / 185 reviews)</span>
                </div>
                <p id="modal-desc" class="text-xs text-on-surface-variant leading-relaxed">Detailed specification highlights and features.</p>
                <div class="border-t border-b border-outline-variant/20 py-4 flex items-center justify-between">
                    <div>
                        <span class="text-xs text-on-surface-variant block font-medium">Special Price</span>
                        <span id="modal-price" class="text-2xl font-extrabold text-primary">₹0</span>
                    </div>
                    <span id="modal-mrp" class="text-sm text-on-surface-variant line-through font-semibold mt-4">₹0</span>
                </div>
            </div>
            
            <button id="modal-add-btn" class="w-full bg-primary text-on-primary py-3.5 rounded-xl font-bold hover:bg-primary/95 transition-all shadow-md mt-6 flex items-center justify-center gap-2">
                <span class="material-symbols-outlined text-xl">add_shopping_cart</span> Add to Shopping Cart
            </button>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="w-full bg-inverse-surface text-white pt-20 pb-8 reveal">
    <div class="px-margin-desktop max-w-container-max mx-auto">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div class="space-y-6">
                <a class="flex items-center gap-3" href="#">
                    <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md">
                        <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                    </div>
                    <span class="font-headline text-2xl font-extrabold tracking-tight">HomeKart</span>
                </a>
                <p class="text-xs text-gray-400 leading-relaxed max-w-xs">
                    Your destination for luxury, energy-efficient smart appliances. Bringing state-of-the-art elegance and intelligence to every home since 2024.
                </p>
                <div class="flex gap-4">
                    <a class="w-10 h-10 rounded-full border border-gray-700 flex items-center justify-center hover:bg-primary hover:border-primary transition-all text-white" href="#"><span class="material-symbols-outlined text-lg">public</span></a>
                    <a class="w-10 h-10 rounded-full border border-gray-700 flex items-center justify-center hover:bg-primary hover:border-primary transition-all text-white" href="#"><span class="material-symbols-outlined text-lg">alternate_email</span></a>
                    <a class="w-10 h-10 rounded-full border border-gray-700 flex items-center justify-center hover:bg-primary hover:border-primary transition-all text-white" href="#"><span class="material-symbols-outlined text-lg">call</span></a>
                </div>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Quick Links</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="#">About Our Store</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Careers & Culture</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Corporate CSR Policy</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Store Locator Near Me</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Partner Dealerships</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Categories</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="#">Luxury Refrigerators</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Split Air Conditioners</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Smart Washers & Laundry</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Integrated Cooktops</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Water Purifiers</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">HomeKart Newsletter</h5>
                <p class="text-xs text-gray-400">Subscribe for the latest deals, premium product launches, and tips.</p>
                <div class="flex flex-col gap-3">
                    <input class="bg-gray-800 border-none rounded-xl px-4 py-3 text-xs w-full focus:ring-2 focus:ring-primary text-white placeholder-gray-500" placeholder="Your email address" type="email"/>
                    <button class="bg-primary text-on-primary px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-[11px] hover:bg-primary-container hover:text-on-primary-container transition-all" onclick="alert('Thanks for subscribing!')">
                        Join Membership
                    </button>
                </div>
            </div>
        </div>
        
        <div class="flex flex-col md:flex-row justify-between items-center gap-8 pt-8 border-t border-gray-800">
            <p class="text-xs text-gray-500">© 2026 HomeKart. All rights reserved.</p>
            <div class="flex flex-wrap justify-center gap-8">
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Privacy Policy</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Terms of Service</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Shipping Information</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Returns & Cancellations</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<script>
    // Product Database for Mock interactions
    const productsDb = {
        1: {
            id: 1,
            name: "Samsung Bespoke Refrigerator",
            price: 64990,
            mrp: 78000,
            rating: "4.8",
            reviews: 185,
            tag: "Bestseller",
            desc: "Add a touch of elegance and customizability to your kitchen. Features smart double door flex layout, AI Smart Control, and high efficiency Digital Inverter technology.",
            image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAjLfFP5hBAUPm-qDSWPH0xN6W47HY8Oey5vccjyMZwVZVpUW0Y4VZAOtmAkhTslFB1wfQ8tuakZl9wpTQd5T6gZ1tGV34K5soX2qRYZwni0qRxtaDQtLHjp6UdiFeqbsRhywMObGJV7keapXT4d46GyeCuJwuijQ7cDeklm9Kssd9Zcgsx9gKHZsjVEzAytj8q53O6mnCvqaSAdXwMyyBz_WG9z21Sr8myYsPnkqj0uXLoKWRiTQer"
        },
        2: {
            id: 2,
            name: "LG AI Direct Drive Washer",
            price: 32490,
            mrp: 42000,
            rating: "4.5",
            reviews: 94,
            tag: "High Efficiency",
            desc: "Designed for premium fabric care. The integrated Artificial Intelligence detects weight and fabric softness to optimize the wash cycle. Powered by Direct Drive Motor.",
            image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBcsVyS6aD4KotNWVRAWMOKxls1MZM5K5D-fcURn2NtpwG5l1q0gyCrOWijNRKcFyihBrzLTP2C8XxTLTaOmCFLPnTOrciDngxebIHdeTAfmaMqudfG3KJMWE6LquLuD_IrdqQvlzbqx73822MNsNiiVK14ebItx44dh4yUyOtpzg8FdHqeXn2OhOh85m4NwQwL0nTMVnb7iqMiL1aqmPM9NCKDE_tMp3CzHa6FWP4WF_t5NrbmOOsD"
        },
        3: {
            id: 3,
            name: "Whirlpool 1.5 Ton Split AC",
            price: 43990,
            mrp: 55000,
            rating: "4.9",
            reviews: 210,
            tag: "5 Star Energy",
            desc: "Premium cooling for extreme Indian summers. Equipped with a 6th Sense Intellicool sensor and high reliability 100% Copper Condenser coils.",
            image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBcFfi4uqYwbjcVCNOtgEojoCerxCAxAwGMNFWjlG4wQ5LO3mWW-s7Zm5KzEfRKTv62hia_9UbvkXrOVmsRqJYmZZq9rPg6NL8bTace1uFRCNCecB1h-hUvO5qVmPUKEvCK0DvCpYyrG8tT4qkZazDZbEQu0F3h_PpAfSD6aFolvNuF8Pqv62MUPn7ZVTe6mYmGlbet28nZusmlxLu9XReGY6unuars_pleFNQfEow3xBium0J5uRzA"
        },
        4: {
            id: 4,
            name: "Bosch 13 Place Dishwasher",
            price: 52990,
            mrp: 62000,
            rating: "4.7",
            reviews: 138,
            tag: "Premium Quality",
            desc: "Optimized for heavy oily Indian utensils. Features a dedicated Intensive Kadhai mode, adjustable baskets, and super silent operation.",
            image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBMBNxw847iHFfMt61eiiunBmAb71SkcjJtq8-doyUaTJn-01R6WoYqxHn4qE_l2a2xQy2uRvbEOGkprWCBczFPL1SI-MTWDGWZeuk6dfdhzfTHviLmuiYW6428OKQ53OXdVMQ3MIal1ID73z8Umf9-6MxfHEUZkNZUDpww4Xkg_iaqO9NMevDSMkNVh0Fyg2i_M652znNC4skgCULFTtkx9QTYAuRbyPxH4PhiNURTZhTijd9xL3Ex"
        }
    };

    // Global Shopping Cart State
    let cart = [];

    // Profile Dropdown Toggle
    const profileBtn = document.getElementById('profile-dropdown-btn');
    const profileMenu = document.getElementById('profile-dropdown');
    profileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        profileMenu.classList.toggle('hidden');
    });
    document.addEventListener('click', () => {
        profileMenu.classList.add('hidden');
    });

    // Hero Slider Functionality
    const sliderWrapper = document.getElementById('hero-slider');
    const dots = document.querySelectorAll('#slider-dots button');
    let currentIndex = 0;
    const totalSlides = 3;

    function updateSlider(index) {
        currentIndex = index;
        sliderWrapper.style.transform = `translateX(-${currentIndex * 100}%)`;
        
        dots.forEach((dot, i) => {
            if (i === currentIndex) {
                dot.classList.add('scale-125', 'bg-white');
                dot.classList.remove('bg-white/50');
            } else {
                dot.classList.remove('scale-125', 'bg-white');
                dot.classList.add('bg-white/50');
            }
        });
    }

    function autoSlide() {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateSlider(currentIndex);
    }

    let slideInterval = setInterval(autoSlide, 5000);

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearInterval(slideInterval);
            updateSlider(index);
            slideInterval = setInterval(autoSlide, 5000);
        });
    });

    // Reveal on Scroll Animations
    function reveal() {
        const reveals = document.querySelectorAll(".reveal");
        for (let i = 0; i < reveals.length; i++) {
            const windowHeight = window.innerHeight;
            const elementTop = reveals[i].getBoundingClientRect().top;
            const elementVisible = 100;
            if (elementTop < windowHeight - elementVisible) {
                reveals[i].classList.add("active");
            }
        }
    }
    window.addEventListener("scroll", reveal);
    reveal();

    // Search Autocomplete Suggestion Logic
    const searchInput = document.getElementById('product-search');
    const suggestionsDropdown = document.getElementById('search-suggestions');
    const suggestionsList = document.getElementById('suggestions-list');

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        if (!query) {
            suggestionsDropdown.classList.add('hidden');
            return;
        }

        const filtered = Object.values(productsDb).filter(p => p.name.toLowerCase().includes(query));
        
        if (filtered.length > 0) {
            suggestionsList.innerHTML = filtered.map(p => `
                <div class="flex items-center gap-3 p-3 hover:bg-primary-fixed/20 cursor-pointer transition-colors" onclick="openProductModal(${p.id})">
                    <img class="w-10 h-10 object-contain bg-white rounded-lg p-1 border border-outline-variant/30" src="${p.image}" alt="${p.name}"/>
                    <div>
                        <p class="text-xs font-bold text-on-surface">${p.name}</p>
                        <p class="text-[10px] text-primary font-bold">₹${p.price.toLocaleString('en-IN')}</p>
                    </div>
                </div>
            `).join('');
            suggestionsDropdown.classList.remove('hidden');
        } else {
            suggestionsList.innerHTML = `<div class="p-4 text-xs text-on-surface-variant text-center">No premium matches found</div>`;
            suggestionsDropdown.classList.remove('hidden');
        }
    });

    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !suggestionsDropdown.contains(e.target)) {
            suggestionsDropdown.classList.add('hidden');
        }
    });

    // Wishlist Toggle
    function toggleWishlist(productId, btn) {
        const icon = btn.querySelector('span');
        if (icon.style.fontVariationSettings.includes("'FILL' 1")) {
            icon.style.fontVariationSettings = "'FILL' 0";
            icon.classList.remove('text-red-500');
        } else {
            icon.style.fontVariationSettings = "'FILL' 1";
            icon.classList.add('text-red-500');
            // Mini toast
            showToast("Added to your exclusive Wishlist!");
        }
    }

    // Cart Drawer Toggle
    function toggleCartDrawer() {
        const drawer = document.getElementById('cart-drawer');
        const overlay = document.getElementById('cart-overlay');
        const panel = document.getElementById('cart-panel');
        
        if (drawer.classList.contains('hidden')) {
            drawer.classList.remove('hidden');
            setTimeout(() => {
                overlay.classList.remove('opacity-0');
                overlay.classList.add('opacity-100');
                panel.classList.remove('translate-x-full');
                panel.classList.add('translate-x-0');
            }, 10);
        } else {
            overlay.classList.remove('opacity-100');
            overlay.classList.add('opacity-0');
            panel.classList.remove('translate-x-0');
            panel.classList.add('translate-x-full');
            setTimeout(() => {
                drawer.classList.add('hidden');
            }, 300);
        }
    }

    // Add To Cart Functionality
    function addToCart(id, name, price, img) {
        const existing = cart.find(item => item.id === id);
        if (existing) {
            existing.qty++;
        } else {
            cart.push({ id, name, price, img, qty: 1 });
        }
        updateCartUi();
        showToast(`Added ${name} to cart.`);
    }

    function removeFromCart(id) {
        cart = cart.filter(item => item.id !== id);
        updateCartUi();
    }

    function changeQty(id, delta) {
        const item = cart.find(i => i.id === id);
        if (item) {
            item.qty += delta;
            if (item.qty <= 0) {
                removeFromCart(id);
            } else {
                updateCartUi();
            }
        }
    }

    function updateCartUi() {
        const badge = document.getElementById('cart-badge');
        const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);
        badge.textContent = totalQty;

        const container = document.getElementById('cart-items-container');
        const emptyMsg = document.getElementById('empty-cart-message');
        const subtotalEl = document.getElementById('cart-subtotal');
        
        if (cart.length === 0) {
            container.innerHTML = '';
            container.appendChild(emptyMsg);
            subtotalEl.textContent = '₹0';
        } else {
            emptyMsg.remove();
            container.innerHTML = cart.map(item => `
                <div class="flex items-center gap-4 bg-surface-container-low p-4 rounded-2xl border border-outline-variant/30">
                    <img class="w-16 h-16 object-contain bg-white p-2 rounded-xl border border-outline-variant/20" src="${item.img}" alt="${item.name}"/>
                    <div class="flex-grow min-w-0">
                        <h4 class="text-xs font-bold text-on-surface truncate">${item.name}</h4>
                        <p class="text-xs text-primary font-bold mt-1">₹${item.price.toLocaleString('en-IN')}</p>
                        
                        <div class="flex items-center gap-3 mt-3">
                            <div class="flex items-center gap-2 bg-white rounded-lg border border-outline-variant/40 px-1 py-0.5">
                                <button class="w-6 h-6 flex items-center justify-center text-xs font-bold hover:bg-surface-container-high rounded" onclick="changeQty(${item.id}, -1)">-</button>
                                <span class="text-xs font-bold w-4 text-center">${item.qty}</span>
                                <button class="w-6 h-6 flex items-center justify-center text-xs font-bold hover:bg-surface-container-high rounded" onclick="changeQty(${item.id}, 1)">+</button>
                            </div>
                            
                            <button class="text-on-surface-variant hover:text-error text-xs flex items-center gap-1" onclick="removeFromCart(${item.id})">
                                <span class="material-symbols-outlined text-base">delete</span>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');

            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            subtotalEl.textContent = '₹' + subtotal.toLocaleString('en-IN');
        }
    }

    // Toast Notification Creator
    function showToast(message) {
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-6 left-6 z-[100] bg-inverse-surface text-inverse-on-surface text-xs font-bold px-5 py-3.5 rounded-xl shadow-xl flex items-center gap-2 border border-outline-variant/20 animate-slide-up';
        toast.innerHTML = `<span class="material-symbols-outlined text-primary">check_circle</span> <span>${message}</span>`;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    // Modal Quick View Control
    function openProductModal(id) {
        window.location.href = '/product/' + id;
    }

    function closeProductModal() {
        const modal = document.getElementById('product-modal');
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
</script>
</body>
</html>
