<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>HomeKart | {{ $product['name'] }} Details</title>
    
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>

    <!-- Vite Assets (Tailwind CSS v4) -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
            display: inline-block;
            vertical-align: middle;
        }
        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        .glass-nav {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }
        .image-zoom-container {
            overflow: hidden;
            border-radius: 1.5rem;
        }
        .image-zoom-container img {
            transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .image-zoom-container:hover img {
            transform: scale(1.08);
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 10px;
        }
    </style>
</head>
<body class="bg-surface text-on-surface font-body overflow-x-hidden antialiased">

<!-- Premium Navigation Bar -->
<header class="fixed top-0 w-full z-50 glass-nav border-b border-outline-variant/40 transition-all duration-300" id="main-header">
    <div class="flex items-center justify-between px-margin-desktop max-w-container-max mx-auto h-20">
        <div class="flex items-center gap-12">
            <a class="flex items-center gap-3 group" href="{{ route('dashboard') }}">
                <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md group-hover:scale-105 transition-transform">
                    <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                </div>
                <span class="font-headline text-2xl font-extrabold text-primary tracking-tight">HomeKart</span>
            </a>
        </div>
        
        <!-- Action Items -->
        <div class="flex items-center gap-8">
            <div class="hidden md:flex items-center gap-2.5 text-primary font-bold bg-primary-fixed/35 px-4 py-2 rounded-xl border border-primary/5">
                <span class="material-symbols-outlined text-lg text-primary">call</span>
                <span class="text-xs font-headline">+91 98765 43210</span>
                <img alt="whatsapp" class="w-5 h-5 ml-1 animate-pulse" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAn9kHDYUKFEgzRQBJpMmsfH72sxUJ-IXcPuukm6CeqTWJONQBiDl0Vag5qro_1pShClp94cSt1x_eUKyyYCQsn1s-vjXzKuh9aspswM6YtcgWaZIPrEPdIZT9bGmwVsB8ftQZ3W65Jo1b1Uzv1jiSyRNJLAuCL9bvOBEvf3flQM4NNem0YNSynIMgYJhWfKsGUbbT4CP8_npk7o7ObdsuXgtRyRACusVJ6Tu3V_X4Cd_Nc-oyuIt2C"/>
            </div>
            
            <div class="flex items-center gap-5">
                <a href="{{ route('dashboard') }}" class="flex items-center gap-2 text-sm font-bold text-primary hover:bg-primary-fixed/20 px-4 py-2.5 rounded-xl transition-all border border-primary/20 shadow-sm bg-white">
                    <span class="material-symbols-outlined text-lg">arrow_back</span>
                    Back to Store
                </a>
            </div>
        </div>
    </div>
    
    <!-- Sub Header Navigation -->
    <nav class="hidden lg:flex items-center justify-center gap-10 h-11 border-t border-outline-variant/40 text-xs uppercase tracking-widest font-bold text-on-surface-variant">
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('categories') }}">
            Categories
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#products">
            Top Sellers
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#sale">
            Offers & Sales
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
        <a class="hover:text-primary transition-colors relative py-2 group" href="{{ route('dashboard') }}#brands">
            Partner Brands
            <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
        </a>
    </nav>
</header>

<main class="pt-32">
    <!-- Breadcrumbs navigation -->
    <nav class="max-w-container-max mx-auto px-margin-desktop py-6 text-xs text-on-surface-variant/80">
        <ol class="flex items-center space-x-2.5">
            <li><a href="{{ route('dashboard') }}" class="hover:text-primary transition-colors">Home</a></li>
            <li><span class="material-symbols-outlined text-xs">keyboard_arrow_right</span></li>
            <li><a href="{{ route('categories') }}" class="hover:text-primary transition-colors">Refrigerators</a></li>
            <li><span class="material-symbols-outlined text-xs">keyboard_arrow_right</span></li>
            <li class="text-on-surface font-bold">{{ $product['name'] }}</li>
        </ol>
    </nav>

    <!-- Product Showcase & Main Info section -->
    <section class="max-w-container-max mx-auto px-margin-desktop pb-16 grid grid-cols-1 lg:grid-cols-12 gap-12">
        <!-- Thumbnails Column -->
        <div class="lg:col-span-1 hidden lg:flex flex-col space-y-4 custom-scrollbar overflow-y-auto max-h-[500px] pr-2">
            <img onclick="switchMainImage('https://lh3.googleusercontent.com/aida-public/AB6AXuA3RPQ9qBvmlLYjJ6ZWRoEbRHzkPSlSJPyrOO_H-pzjrszXE0O8pvILfHJ4vElC8gOp23oF8FqYoRku0BZdwygyCHdXDFbt8CTivH3EbXXV5vTI1Qid2U9l2iwJ_YJSw49MtaOrMgRZp1yuVaW5qjReuVdPggvPimR2bSgPkGGqynOoJWoteD_Jz69Vh9ymiQrSqb8RBHLQGCDKuG3eJ5Yhm50f1eWTunpfoDIqCjVjVcEgSW8Sevm2', this)" alt="View 1" class="border-2 border-primary rounded-xl cursor-pointer p-1.5 bg-white aspect-square object-contain thumbnail-btn" />
            <img onclick="switchMainImage('https://lh3.googleusercontent.com/aida-public/AB6AXuDk_fIvlLtYvvzi7QxsuZAyjm4RQEe9Zbekp7KIG6oSS5BLg3XEMXTYvj90zto2Q2-SHAZdpT9cRUCFGpwo0aE_5i-iu6oEvgs6JdVHNA1_UN4hx0t-ijrPUFUHfJzosJwCWheUcI-GnqFQ1FG5wpVUfYI8uNmQwYS6oZV9iDah_i_XG2uA_wudSUhxDyvQBcckZ5gQHI09SGX6FGh84ikoemlsBGVYuNeELs_pS1Hp6X3F3B6_UDMx', this)" alt="View 2" class="border border-outline-variant/30 rounded-xl cursor-pointer p-1.5 bg-white aspect-square object-contain thumbnail-btn" />
            <img onclick="switchMainImage('https://lh3.googleusercontent.com/aida-public/AB6AXuDlD_mqp7c5e6uaPx-bWRmGTXBHbFNXLJuMXsnBP2Pd2rD4AaI7Anda0febzY8tHh6OxqE-gltvfDJDjseOZiB8c5nzrqbLAqx0GDoFfCUcTTpap_1UWkWHtjgVlVjgZVaZOuBshqhbIuBnN_kGp-wG83GvL3PZ5UXLyuWbPUPLLmLtZQU5Pd2beBxWdYSHNWkih7vauGyOsUsrrvHdpD3ej6UQGsgGa5biOXHZ3jnspgGBKu9Fi-QM', this)" alt="View 3" class="border border-outline-variant/30 rounded-xl cursor-pointer p-1.5 bg-white aspect-square object-contain thumbnail-btn" />
            <img onclick="switchMainImage('https://lh3.googleusercontent.com/aida-public/AB6AXuCUIo9nZZw5kVirVmgald8fL1vg97LjJgKfUtAdooK5FlAfBdqPf9Zt_EDEz1uXDy-vw_O4MoiFa3qsR3iI35sZ_SP8aB9T0tYe1-scRa7830GKajr5nMX9Hvr12641ZsRYHwVY7sYmEdcDgWtOTQOSH3uByspgRWsyJhyI4F1j_V090sFMVq9t7UXXIERAn8fHQ-Joyi7F_t0hQi4_oh74XuyARf60jTGdUV7Qw1I47xAJ2-HH2wj4', this)" alt="View 4" class="border border-outline-variant/30 rounded-xl cursor-pointer p-1.5 bg-white aspect-square object-contain thumbnail-btn" />
            <img onclick="switchMainImage('https://lh3.googleusercontent.com/aida-public/AB6AXuDjN0i62pPAHU4eYIQ4P8AZyX8lvEbwjg7prDjHXzrikhKnW-vqAFSETtYvwa3DEbgJOSi8wnrbXFezv_ghc_i-jS7YAuUw-ZSnmCeFxhgCo2AeWsCJdv_uOotkqx6keDRbiK1nrCzr4cv-lTfSW8GoOqSMCRXVPSDd3JXasJ2oBwOq5h1AFlsXRp5xfPiW8hl2Adv3YOJtjYHzih0dLaDUEf5yPFQzMga6hsDBB3hBy_Nj0qwZ7jDJ', this)" alt="View 5" class="border border-outline-variant/30 rounded-xl cursor-pointer p-1.5 bg-white aspect-square object-contain thumbnail-btn" />
        </div>

        <!-- Main Display Column -->
        <div class="lg:col-span-5 bg-white rounded-3xl p-8 flex items-center justify-center border border-outline-variant/40 shadow-sm relative group overflow-hidden">
            <span class="absolute top-4 left-4 bg-green-100 border border-green-200 text-green-700 text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider z-10 shadow-xs">
                In Stock
            </span>
            <button class="absolute top-4 right-4 p-2.5 bg-white/80 backdrop-blur-md rounded-full shadow-md hover:bg-white hover:text-red-500 transition-colors z-10" onclick="alert('Added product to wishlist!')">
                <span class="material-symbols-outlined text-[20px]">favorite</span>
            </button>
            
            <div class="image-zoom-container h-[480px] w-full flex items-center justify-center cursor-crosshair">
                <img id="main-product-image" alt="{{ $product['name'] }}" class="max-h-full object-contain" src="{{ $product['image'] }}"/>
            </div>
        </div>

        <!-- Specifications & Purchase Details Column -->
        <div class="lg:col-span-6 space-y-6 flex flex-col justify-between">
            <div class="space-y-4">
                <span class="bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider inline-block">HomeKart Recommended</span>
                <h1 class="font-headline text-3xl font-extrabold text-on-surface leading-tight">{{ $product['name'] }}</h1>
                
                <div class="flex items-center gap-3">
                    <div class="flex items-center gap-1 bg-green-600 text-white px-2.5 py-0.5 rounded-lg text-xs font-bold shadow-sm">
                        {{ $product['rating'] }} <span class="material-symbols-outlined text-xs" style="font-variation-settings: 'FILL' 1;">star</span>
                    </div>
                    <span class="text-on-surface-variant font-bold text-xs">({{ $product['reviews'] }} Verified Customer Reviews)</span>
                </div>

                <!-- Star Icons / Tech Indicators Grid -->
                <div class="grid grid-cols-4 gap-4 py-6 border-y border-outline-variant/40">
                    <div class="text-center bg-surface-container-low p-3 rounded-2xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-on-surface-variant text-xl mb-1">layers</span>
                        <p class="text-[9px] text-on-surface-variant uppercase font-bold tracking-widest">Capacity</p>
                        <p class="text-xs font-extrabold text-primary mt-0.5">{{ $product['capacity'] ?? 'N/A' }}</p>
                    </div>
                    <div class="text-center bg-surface-container-low p-3 rounded-2xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-on-surface-variant text-xl mb-1">star</span>
                        <p class="text-[9px] text-on-surface-variant uppercase font-bold tracking-widest">Star Rating</p>
                        <p class="text-xs font-extrabold text-primary mt-0.5">3 Star</p>
                    </div>
                    <div class="text-center bg-surface-container-low p-3 rounded-2xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-on-surface-variant text-xl mb-1">shield</span>
                        <p class="text-[9px] text-on-surface-variant uppercase font-bold tracking-widest">Warranty</p>
                        <p class="text-xs font-extrabold text-primary mt-0.5">1 Year</p>
                    </div>
                    <div class="text-center bg-surface-container-low p-3 rounded-2xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-on-surface-variant text-xl mb-1">bolt</span>
                        <p class="text-[9px] text-on-surface-variant uppercase font-bold tracking-widest">Inverter</p>
                        <p class="text-xs font-extrabold text-primary mt-0.5">Smart Inverter</p>
                    </div>
                </div>

                <!-- Pricing Block -->
                <div class="py-2 space-y-1">
                    <div class="flex items-baseline gap-3">
                        <span class="text-3xl font-extrabold text-primary">₹{{ number_format($product['price']) }}</span>
                        <span class="text-sm text-on-surface-variant/70 line-through font-bold">₹{{ number_format($product['mrp']) }}</span>
                        <span class="text-secondary text-xs font-bold px-2 py-0.5 bg-secondary-container rounded-lg text-on-secondary-container">{{ round((($product['mrp'] - $product['price']) / $product['mrp']) * 100) }}% OFF</span>
                    </div>
                    <p class="text-[10px] text-on-surface-variant/80 font-bold">(Price inclusive of GST and local taxes)</p>
                </div>

                <!-- Offers Box -->
                <div class="bg-primary/5 p-4 rounded-2xl border border-primary/20 space-y-3">
                    <div class="flex items-center gap-2 text-xs font-extrabold text-primary uppercase tracking-widest">
                        <span class="material-symbols-outlined text-base">local_offer</span>
                        Available Bank Offers
                    </div>
                    <ul class="text-xs text-on-surface-variant space-y-2 font-medium">
                        <li class="flex items-start gap-1.5">
                            <span class="text-primary font-bold">•</span>
                            10% Instant Discount on HDFC Bank Credit Cards.
                        </li>
                        <li class="flex items-start gap-1.5">
                            <span class="text-primary font-bold">•</span>
                            Up to ₹2,000 extra exchange discount on old refrigerators.
                        </li>
                    </ul>
                    <button class="text-[11px] font-bold text-primary hover:underline" onclick="alert('Viewing detailed discount policies.')">View All Offers</button>
                </div>
            </div>

            <!-- CTA Call actions -->
            <div class="space-y-4 pt-4">
                <div class="flex flex-col sm:flex-row gap-4">
                    <button class="flex-1 bg-primary text-on-primary py-4 rounded-xl font-bold hover:bg-primary-container transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer" onclick="alert('Product inquiry details submitted!')">
                        <span class="material-symbols-outlined text-lg">shopping_bag</span>
                        Enquire Now
                    </button>
                    <button class="flex-1 border-2 border-primary text-primary py-4 rounded-xl font-bold hover:bg-primary-fixed/20 transition-all flex items-center justify-center gap-2 cursor-pointer">
                        <span class="material-symbols-outlined text-lg">call</span>
                        Call Hotline
                    </button>
                </div>
                <button class="w-full flex items-center justify-center gap-2 py-3 border border-green-500 text-green-600 rounded-xl font-bold hover:bg-green-50 transition-colors cursor-pointer" onclick="window.open('https://wa.me/919876543210')">
                    <img alt="WA" class="w-5 h-5 brightness-100" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAn9kHDYUKFEgzRQBJpMmsfH72sxUJ-IXcPuukm6CeqTWJONQBiDl0Vag5qro_1pShClp94cSt1x_eUKyyYCQsn1s-vjXzKuh9aspswM6YtcgWaZIPrEPdIZT9bGmwVsB8ftQZ3W65Jo1b1Uzv1jiSyRNJLAuCL9bvOBEvf3flQM4NNem0YNSynIMgYJhWfKsGUbbT4CP8_npk7o7ObdsuXgtRyRACusVJ6Tu3V_X4Cd_Nc-oyuIt2C"/>
                    Chat on WhatsApp
                </button>

                <!-- Small badges -->
                <div class="grid grid-cols-4 gap-2 text-[8px] lg:text-[9px] text-on-surface-variant font-bold border-t border-outline-variant/30 pt-6">
                    <div class="flex flex-col items-center p-2.5 bg-surface-container-low rounded-xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-primary text-lg mb-1">local_shipping</span>
                        FREE DELIVERY
                    </div>
                    <div class="flex flex-col items-center p-2.5 bg-surface-container-low rounded-xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-primary text-lg mb-1">handyman</span>
                        INSTALLATION
                    </div>
                    <div class="flex flex-col items-center p-2.5 bg-surface-container-low rounded-xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-primary text-lg mb-1">payments</span>
                        EASY EMI
                    </div>
                    <div class="flex flex-col items-center p-2.5 bg-surface-container-low rounded-xl border border-outline-variant/20">
                        <span class="material-symbols-outlined text-primary text-lg mb-1">shield</span>
                        WARRANTY
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Detailed Tabs Section -->
    <section class="max-w-container-max mx-auto px-margin-desktop py-16 border-t border-outline-variant/30 reveal active">
        <div class="border-b border-outline-variant/30 mb-8 overflow-x-auto">
            <ul class="flex space-x-8 text-sm font-bold min-w-max" id="detail-tabs">
                <li class="border-b-2 border-primary text-primary pb-4 px-2 cursor-pointer transition-all" onclick="switchTab('overview', this)">Overview</li>
                <li class="text-on-surface-variant hover:text-primary cursor-pointer pb-4 px-2 transition-all" onclick="switchTab('specs', this)">Specifications</li>
                <li class="text-on-surface-variant hover:text-primary cursor-pointer pb-4 px-2 transition-all" onclick="switchTab('features', this)">Features</li>
                <li class="text-on-surface-variant hover:text-primary cursor-pointer pb-4 px-2 transition-all" onclick="switchTab('reviews', this)">Reviews ({{ $product['reviews'] }})</li>
            </ul>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12" id="tabs-content-container">
            <!-- Left Info Block -->
            <div class="lg:col-span-8 space-y-6">
                <!-- Overview Tab Content -->
                <div id="tab-overview" class="tab-pane space-y-6">
                    <h2 class="font-headline text-xl font-extrabold text-on-surface">{{ $product['name'] }}</h2>
                    <p class="text-on-surface-variant leading-relaxed text-sm">
                        {{ $product['desc'] }}
                    </p>
                    <ul class="grid grid-cols-1 md:grid-cols-2 gap-y-3 text-xs font-bold text-on-surface-variant">
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Smart Inverter Compressor</li>
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Multi Air Flow Cooling</li>
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Toughened Glass Shelves</li>
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Moist 'N' Fresh Crisp</li>
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Anti-Bacterial Gasket</li>
                        <li class="flex items-center"><span class="w-1.5 h-1.5 bg-primary rounded-full mr-3"></span> Smart Diagnosis Systems</li>
                    </ul>
                </div>

                <!-- Specs Tab Content (Hidden by default) -->
                <div id="tab-specs" class="tab-pane hidden space-y-4">
                    <h2 class="font-headline text-xl font-extrabold text-on-surface">Technical Specifications</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-medium">
                        <div class="flex justify-between border-b border-outline-variant/20 py-2.5">
                            <span class="text-on-surface-variant">Compressor Type</span>
                            <span class="font-bold text-on-surface">Smart Inverter Compressor</span>
                        </div>
                        <div class="flex justify-between border-b border-outline-variant/20 py-2.5">
                            <span class="text-on-surface-variant">Stabilizer Free Operation</span>
                            <span class="font-bold text-on-surface">Yes (100V ~ 310V)</span>
                        </div>
                        <div class="flex justify-between border-b border-outline-variant/20 py-2.5">
                            <span class="text-on-surface-variant">Shelves Material</span>
                            <span class="font-bold text-on-surface">Toughened Glass (2 Shelves)</span>
                        </div>
                        <div class="flex justify-between border-b border-outline-variant/20 py-2.5">
                            <span class="text-on-surface-variant">Defrosting Type</span>
                            <span class="font-bold text-on-surface">Frost Free</span>
                        </div>
                    </div>
                </div>

                <!-- Features Tab Content (Hidden by default) -->
                <div id="tab-features" class="tab-pane hidden space-y-4">
                    <h2 class="font-headline text-xl font-extrabold text-on-surface">Product Features</h2>
                    <p class="text-xs text-on-surface-variant leading-relaxed">
                        LG’s Smart Inverter Compressor takes energy efficiency to another level, helping you save money and conserve energy. Not only is it quiet in operation, but it is also backed by a 10-year warranty on the compressor. The Multi Air Flow system ensures temperature levels are maintained throughout the unit.
                    </p>
                </div>

                <!-- Reviews Tab Content (Hidden by default) -->
                <div id="tab-reviews" class="tab-pane hidden space-y-4">
                    <h2 class="font-headline text-xl font-extrabold text-on-surface">Customer Reviews</h2>
                    <div class="space-y-4">
                        <div class="border-b border-outline-variant/20 pb-4">
                            <div class="flex items-center gap-2 mb-1.5">
                                <span class="text-xs font-bold text-on-surface">Ramesh Kumar</span>
                                <span class="text-secondary text-[10px]">★★★★★</span>
                            </div>
                            <p class="text-xs text-on-surface-variant leading-relaxed">Amazing refrigerator. Extremely quiet operation and very efficient cooling. The Shiny Steel color matches our kitchen perfectly.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Info Block: Product info box -->
            <div class="lg:col-span-4 bg-white p-6 rounded-3xl border border-outline-variant/40 shadow-sm h-fit">
                <h3 class="font-headline text-md font-bold mb-6 text-on-surface border-b border-outline-variant/20 pb-4">Quick Factsheet</h3>
                <div class="space-y-4 text-xs font-medium">
                    <div class="flex justify-between border-b border-outline-variant/10 pb-2">
                        <span class="text-on-surface-variant">Brand</span>
                        <span class="font-bold text-on-surface">{{ $product['brand'] ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between border-b border-outline-variant/10 pb-2">
                        <span class="text-on-surface-variant">Model</span>
                        <span class="font-bold text-on-surface">{{ $product['model'] ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between border-b border-outline-variant/10 pb-2">
                        <span class="text-on-surface-variant">Capacity</span>
                        <span class="font-bold text-on-surface">{{ $product['capacity'] ?? 'N/A' }}</span>
                    </div>
                    <div class="flex justify-between border-b border-outline-variant/10 pb-2">
                        <span class="text-on-surface-variant">Color</span>
                        <span class="font-bold text-on-surface">Shiny Steel</span>
                    </div>
                    <div class="flex justify-between border-b border-outline-variant/10 pb-2">
                        <span class="text-on-surface-variant">Energy Rating</span>
                        <span class="font-bold text-on-surface">3 Star Rating</span>
                    </div>
                </div>

                <div class="mt-6 border-t border-outline-variant/20 pt-4">
                    <p class="text-xs font-bold mb-3 text-on-surface">Available Options</p>
                    <div class="flex space-x-3.5">
                        <div class="w-6 h-6 rounded-full bg-slate-400 border-2 border-white shadow-md cursor-pointer hover:scale-110 transition-transform"></div>
                        <div class="w-6 h-6 rounded-full bg-slate-800 border-2 border-white shadow-md cursor-pointer hover:scale-110 transition-transform"></div>
                        <div class="w-6 h-6 rounded-full bg-red-800 border-2 border-white shadow-md cursor-pointer hover:scale-110 transition-transform"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Related Products section -->
    <section class="max-w-container-max mx-auto px-margin-desktop py-20 border-t border-outline-variant/30 reveal">
        <div class="flex justify-between items-end mb-12">
            <div>
                <span class="text-xs font-bold text-primary tracking-widest uppercase">Matching Items</span>
                <h2 class="font-headline text-3xl font-extrabold mt-1 text-on-surface">Related Products</h2>
            </div>
            <a class="text-primary text-xs font-bold hover:underline flex items-center gap-1.5 uppercase tracking-widest" href="{{ route('categories') }}">
                View All
                <span class="material-symbols-outlined text-sm">open_in_new</span>
            </a>
        </div>
        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <!-- Related Item 1 -->
            <div class="bg-white border border-outline-variant/40 rounded-3xl p-5 group hover:shadow-xl hover:border-primary/20 transition-all flex flex-col justify-between">
                <div class="relative overflow-hidden h-48 mb-4 flex items-center justify-center bg-surface-container-low rounded-2xl p-4">
                    <img alt="Samsung" class="max-h-full object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDO_BGm8aS13Cpo1iEKeFuf5kWwNfAAgnG-ke8jryiKlFQK0iudT5FtM6MMCd3I0JX-2xhFcmDjTP6_bRa4H101OTJwSRy7SCGgtBaaFpFjxrnSlpIiEFsjI_kfOzEnnmBbrWOVEJ_wnR30s4bPydsUgd12Av2YhCUatfCKvLawrvEZtNzk1HE32K5mkgwpIcbNBTnGmsADfVketk4bYM-QF1JrqZ79Q_wmfqzBewiflT6Lvx0pKdb4"/>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-on-surface group-hover:text-primary transition-colors line-clamp-2">Samsung Double Door Refrigerator</h4>
                    <div class="flex items-center justify-between mt-3 border-t border-outline-variant/10 pt-3">
                        <span class="text-sm font-extrabold text-primary">₹34,990</span>
                        <span class="text-[10px] text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded font-extrabold">4.5★</span>
                    </div>
                </div>
            </div>

            <!-- Related Item 2 -->
            <div class="bg-white border border-outline-variant/40 rounded-3xl p-5 group hover:shadow-xl hover:border-primary/20 transition-all flex flex-col justify-between">
                <div class="relative overflow-hidden h-48 mb-4 flex items-center justify-center bg-surface-container-low rounded-2xl p-4">
                    <img alt="Whirlpool" class="max-h-full object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCKVgc2XFTSHu5fdiwGi9wfcEuoEAXXX4dp6H4_naZWate4G-wS9Ihw7COe4RLbKGx6VmsipqNYpsbkdeE-8kMMXe0s3J8YdHoMx_ffLr1eU74UR30nJpg5Zyb5NSNyYhPPzndKcXgYZ4sFbDrDPZur-YlFPvOGAjpSbHtxX5V9WJZaBCF-QDPcdK0xE6I-HtWfnJdWkY-lW1WLInLQJJtqO7Q2H_mrKO0bZtvH4FYFmIGBlLmqyt0a"/>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-on-surface group-hover:text-primary transition-colors line-clamp-2">Whirlpool Double Door Refrigerator</h4>
                    <div class="flex items-center justify-between mt-3 border-t border-outline-variant/10 pt-3">
                        <span class="text-sm font-extrabold text-primary">₹30,990</span>
                        <span class="text-[10px] text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded font-extrabold">4.3★</span>
                    </div>
                </div>
            </div>

            <!-- Related Item 3 -->
            <div class="bg-white border border-outline-variant/40 rounded-3xl p-5 group hover:shadow-xl hover:border-primary/20 transition-all flex flex-col justify-between">
                <div class="relative overflow-hidden h-48 mb-4 flex items-center justify-center bg-surface-container-low rounded-2xl p-4">
                    <img alt="Haier" class="max-h-full object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCLzoU2wvSB4UhgSIdjTR-5kI338oLMTCxc81s669s8hg4M5-MJ5js-TvqK4P2iPlAzwOTrrKTutlUUs7OlZnhFkaHwMI9sWeLP-Ia-PgEKSkwnxoUyogUDqkJ5JbNEkPjU4ILyJU8LF5W9V0d50H3Wpe0SkIaycsF-Ku0PRZOnim0YiaSTD_wszGMpIa0qLIPaF6RN2AMiL_Ez_P61QC2BaSGtycffZyVAYP3msKXElX1rhFVpdxlU"/>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-on-surface group-hover:text-primary transition-colors line-clamp-2">Haier Side by Side Refrigerator</h4>
                    <div class="flex items-center justify-between mt-3 border-t border-outline-variant/10 pt-3">
                        <span class="text-sm font-extrabold text-primary">₹65,990</span>
                        <span class="text-[10px] text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded font-extrabold">4.6★</span>
                    </div>
                </div>
            </div>

            <!-- Related Item 4 -->
            <div class="bg-white border border-outline-variant/40 rounded-3xl p-5 group hover:shadow-xl hover:border-primary/20 transition-all flex flex-col justify-between">
                <div class="relative overflow-hidden h-48 mb-4 flex items-center justify-center bg-surface-container-low rounded-2xl p-4">
                    <img alt="LG" class="max-h-full object-contain group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAAA28D3xze5LAfGmLpzoqDErFIH4plXi4QsdLOSV4CL6l0uNh_eqXgIPO45V_mtv1clC9kAZVhZyfFvrLTPlKniDLLHc8cvEy5rJjavNs9Tht9XCkYuQUIW18o7HxMH6-10wQAfKfPhJjR6v8en_46QN2U_GnIXsh72nft8LtpzLy-lufkUwDUaaCJpshcbYbrMxi3FjIi5RyQh9r0g8chlTmWk3ME5KMWG18wzSp-K5cP2YVoqrM0"/>
                </div>
                <div>
                    <h4 class="text-xs font-bold text-on-surface group-hover:text-primary transition-colors line-clamp-2">LG Convertible Refrigerator</h4>
                    <div class="flex items-center justify-between mt-3 border-t border-outline-variant/10 pt-3">
                        <span class="text-sm font-extrabold text-primary">₹37,990</span>
                        <span class="text-[10px] text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded font-extrabold">4.5★</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Footer -->
<footer class="w-full bg-inverse-surface text-white pt-20 pb-8">
    <div class="px-margin-desktop max-w-container-max mx-auto">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div class="space-y-6">
                <a class="flex items-center gap-3" href="{{ route('dashboard') }}">
                    <div class="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-on-primary shadow-md">
                        <span class="material-symbols-outlined text-2xl" style="font-variation-settings: 'FILL' 1;">home</span>
                    </div>
                    <span class="font-headline text-2xl font-extrabold tracking-tight">HomeKart</span>
                </a>
                <p class="text-xs text-gray-400 leading-relaxed max-w-xs">
                    Your destination for luxury, energy-efficient smart appliances. Bringing state-of-the-art elegance and intelligence to every home since 2024.
                </p>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Quick Links</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="{{ route('dashboard') }}">Home Store</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">About Our Store</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Careers & Culture</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Store Locator Near Me</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Top Categories</h5>
                <ul class="space-y-3.5 text-xs text-gray-400">
                    <li><a class="hover:text-white transition-colors" href="#">Luxury Refrigerators</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Split Air Conditioners</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Smart Washers & Laundry</a></li>
                    <li><a class="hover:text-white transition-colors" href="#">Water Purifiers</a></li>
                </ul>
            </div>
            
            <div class="space-y-6">
                <h5 class="font-bold text-sm uppercase tracking-wider text-primary">Store Address</h5>
                <ul class="space-y-3 text-xs text-gray-400">
                    <li class="flex items-start gap-2">
                        <span class="material-symbols-outlined text-sm mt-0.5 text-primary">location_on</span>
                        <span>123, MG Road, Indiranagar, Bengaluru, Karnataka - 560038</span>
                    </li>
                    <li class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-sm text-primary">call</span>
                        <span>+91 98765 43210</span>
                    </li>
                    <li class="flex items-center gap-2">
                        <span class="material-symbols-outlined text-sm text-primary">schedule</span>
                        <span>Mon - Sun: 10:00 AM - 8:00 PM</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="flex flex-col md:flex-row justify-between items-center gap-8 pt-8 border-t border-gray-800">
            <p class="text-xs text-gray-500">© 2026 HomeKart. All rights reserved.</p>
            <div class="flex flex-wrap justify-center gap-8">
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Privacy Policy</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Terms of Service</a>
                <a class="text-gray-500 hover:text-white text-xs transition-colors" href="#">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<script>
    // Gallery Image Switcher
    function switchMainImage(imageUrl, element) {
        document.getElementById('main-product-image').src = imageUrl;
        
        // Update active class on thumbnails
        const thumbs = document.querySelectorAll('.thumbnail-btn');
        thumbs.forEach(t => {
            t.classList.remove('border-primary', 'border-2');
            t.classList.add('border', 'border-outline-variant/30');
        });
        element.classList.add('border-primary', 'border-2');
        element.classList.remove('border', 'border-outline-variant/30');
    }

    // Tab Switcher Logic
    function switchTab(tabName, element) {
        // Toggle tab highlights
        const tabList = document.querySelectorAll('#detail-tabs li');
        tabList.forEach(tab => {
            tab.classList.remove('border-b-2', 'border-primary', 'text-primary');
            tab.classList.add('text-on-surface-variant');
        });
        element.classList.add('border-b-2', 'border-primary', 'text-primary');
        element.classList.remove('text-on-surface-variant');

        // Toggle pane visibility
        const panes = document.querySelectorAll('.tab-pane');
        panes.forEach(pane => pane.classList.add('hidden'));
        
        const targetPane = document.getElementById('tab-' + tabName);
        if (targetPane) {
            targetPane.classList.remove('hidden');
        }
    }

    // Reveal on Scroll Animations
    function reveal() {
        const reveals = document.querySelectorAll(".reveal");
        for (let i = 0; i < reveals.length; i++) {
            const windowHeight = window.innerHeight;
            const elementTop = reveals[i].getBoundingClientRect().top;
            const elementVisible = 100;
            if (elementTop < windowHeight - elementVisible) {
                reveals[i].classList.add("active");
            }
        }
    }
    window.addEventListener("scroll", reveal);
    reveal();
</script>
</body>
</html>
