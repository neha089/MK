<?php

use Illuminate\Support\Facades\Route;

use App\Models\Product;
use App\Http\Controllers\Admin\ProductController;

Route::get('/', function () {
    return view('auth.login');
});

Route::get('/dashboard', function () {
    $products = Product::all();
    return view('dashboard', compact('products'));
})->name('dashboard');

Route::get('/categories', function () {
    return view('categories');
})->name('categories');

// Frontend route for dynamic product details
Route::get('/product/{id}', function ($id) {
    if ($id === 'lg-refrigerator') {
        return redirect()->route('product.detail', ['id' => 1]);
    }
    
    $product = Product::findOrFail($id);
    return view('product', compact('product'));
})->name('product.detail');

// Backend admin routes
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/products/create', [ProductController::class, 'create'])->name('product.create');
    Route::post('/products/store', [ProductController::class, 'store'])->name('product.store');
});

